/**
 * 숫자만 입력해도 휴대폰/전화번호 형태로 보기 좋게 포맷.
 * - 입력값에서 숫자만 추출
 * - 한국 번호 일반 케이스 위주(010 / 02 / 0xx)
 * - 길이 초과는 11자리까지만 사용
 */
export function formatPhoneInput(raw: string): string {
  const digits = (raw || "").replace(/\D/g, "");
  if (!digits) return "";

  // 02 지역번호 특례
  if (digits.startsWith("02")) {
    const d = digits.slice(0, 10); // 02 + (max 8)
    if (d.length <= 2) return d;
    if (d.length <= 6) return `${d.slice(0, 2)}-${d.slice(2)}`;
    if (d.length <= 10) return `${d.slice(0, 2)}-${d.slice(2, 6)}-${d.slice(6)}`;
    return `${d.slice(0, 2)}-${d.slice(2, 6)}-${d.slice(6, 10)}`;
  }

  const d = digits.slice(0, 11);

  if (d.length <= 3) return d;
  if (d.length <= 7) return `${d.slice(0, 3)}-${d.slice(3)}`;
  if (d.length <= 11) return `${d.slice(0, 3)}-${d.slice(3, 7)}-${d.slice(7)}`;

  return `${d.slice(0, 3)}-${d.slice(3, 7)}-${d.slice(7, 11)}`;
}

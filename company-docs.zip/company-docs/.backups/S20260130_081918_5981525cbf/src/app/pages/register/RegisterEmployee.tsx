import { useState } from "react";
import { formatPhoneInput } from "../../../base/utils/phone";

type Branch = "대구" | "성주";

type Employee = {
  id: string;
  name: string;
  branch: Branch;
  phone: string;
  job: string;
  memo: string;
  createdAt: string;
  updatedAt: string;
};

const STORAGE_KEY = "local_employees_v1";

function newId() {
  // @ts-ignore
  return (globalThis.crypto?.randomUUID?.() as string) || `E_${Date.now()}_${Math.floor(Math.random() * 1e6)}`;
}

function loadEmployees(): Employee[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as Employee[];
  } catch {
    return [];
  }
}

function saveEmployees(list: Employee[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

export default function RegisterEmployee() {
  const [list, setList] = useState<Employee[]>(() => loadEmployees());

  const [name, setName] = useState("");
  const [branch, setBranch] = useState<Branch>("대구");
  const [phone, setPhone] = useState("");
  const [job, setJob] = useState("");
  const [memo, setMemo] = useState("");

  function reset() {
    setName("");
    setBranch("대구");
    setPhone("");
    setJob("");
    setMemo("");
  }

  function submit() {
    if (!name.trim()) return alert("이름을 입력하세요.");
    if (!phone.trim()) return alert("연락처를 입력하세요.");
    if (!job.trim()) return alert("직무를 입력하세요.");

    const now = new Date().toISOString();

    const e: Employee = {
      id: newId(),
      name: name.trim(),
      branch,
      phone: phone.trim(),
      job: job.trim(),
      memo: memo.trim(),
      createdAt: now,
      updatedAt: now,
    };

    const next = [e, ...list];
    setList(next);
    saveEmployees(next);
    reset();
    alert("저장되었습니다.(로컬)");
  }

  function remove(id: string) {
    const next = list.filter((x) => x.id !== id);
    setList(next);
    saveEmployees(next);
  }

  return (
    <div className="card">
      <h1 className="h1">직원 등록</h1>
      <p className="p">이름/지부/연락처/직무를 기준정보로 저장합니다.</p>

      <div style={{ marginTop: 14, display: "grid", gap: 10 }}>
        <div>
          <div className="p" style={{ marginTop: 0 }}>이름</div>
          <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="예: 홍길동" />
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>지부</div>
          <div className="row" style={{ marginTop: 8 }}>
            {(["대구", "성주"] as const).map((b) => (
              <button key={b} type="button" className={`selBtn ${branch === b ? "active" : ""}`} onClick={() => setBranch(b)}>
                {b}
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>연락처</div>
          <input
            className="input"
            inputMode="numeric"
            value={phone}
            onChange={(e) => setPhone(formatPhoneInput(e.target.value))}
            placeholder="숫자만 입력 가능"
          />
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>직무</div>
          <input className="input" value={job} onChange={(e) => setJob(e.target.value)} placeholder="자유기입" />
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>참고사항</div>
          <textarea className="textarea" rows={2} value={memo} onChange={(e) => setMemo(e.target.value)} placeholder="짧게(2줄)" />
        </div>
      </div>

      <div className="row">
        <button type="button" className="btn primary" onClick={submit}>
          저장(로컬)
        </button>
      </div>

      <div className="divider" />

      <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
        <div className="h1" style={{ fontSize: 15 }}>저장된 직원</div>

        {list.length === 0 ? (
          <p className="p">아직 없음</p>
        ) : (
          list.map((e) => (
            <div key={e.id} className="card" style={{ marginTop: 10, background: "rgba(255,255,255,0.02)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                <div>
                  <div style={{ fontWeight: 900 }}>{e.name}</div>
                  <div className="p" style={{ marginTop: 6 }}>{e.branch} · {e.phone}</div>
                  <div className="p" style={{ marginTop: 6 }}>직무: {e.job}</div>
                  {e.memo ? <div className="p" style={{ marginTop: 6 }}>참고사항: {e.memo}</div> : null}
                </div>

                <button type="button" className="btn danger" onClick={() => remove(e.id)}>
                  삭제
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

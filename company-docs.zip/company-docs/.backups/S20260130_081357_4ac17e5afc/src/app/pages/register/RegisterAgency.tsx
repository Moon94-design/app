import { useMemo, useState } from "react";

type Status = "거래중" | "보류" | "중단";

type AgencyType =
  | "감독/점검"
  | "검사/측정"
  | "민원/신고 대응"
  | "지원사업/보조금"
  | "기타";

type Scope =
  | "환경"
  | "품질"
  | "안전"
  | "유통/표기"
  | "세무/회계"
  | "지원사업"
  | "기타";

type Contact = {
  id: string;
  name: string;
  role: string;
  phone: string;
  email: string;
  note: string;
};

type Agency = {
  id: string;
  name: string;
  status: Status;

  agencyType: AgencyType;
  agencyTypeOther: string;

  region: string;

  scopes: Scope[];
  scopeNotes: Record<string, string>; // 선택된 scope별 1줄 설명(필수)
  scopeOther: string;                 // 기타 scope 선택 시

  contacts: Contact[];
  notes: string; // 2줄(작게)

  createdAt: string;
  updatedAt: string;
};

const STORAGE_KEY = "local_agencies_v1";

const TYPE_OPTIONS: AgencyType[] = [
  "감독/점검",
  "검사/측정",
  "민원/신고 대응",
  "지원사업/보조금",
  "기타",
];

const SCOPE_OPTIONS: Scope[] = [
  "환경",
  "품질",
  "안전",
  "유통/표기",
  "세무/회계",
  "지원사업",
  "기타",
];

function newId() {
  // @ts-ignore
  return (globalThis.crypto?.randomUUID?.() as string) || `A_${Date.now()}_${Math.floor(Math.random() * 1e6)}`;
}

function loadAgencies(): Agency[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as Agency[];
  } catch {
    return [];
  }
}

function saveAgencies(list: Agency[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

export default function RegisterAgency() {
  const [list, setList] = useState<Agency[]>(() => loadAgencies());

  const [name, setName] = useState("");
  const [status, setStatus] = useState<Status>("거래중");

  const [agencyType, setAgencyType] = useState<AgencyType>("감독/점검");
  const [agencyTypeOther, setAgencyTypeOther] = useState("");

  const [region, setRegion] = useState("");

  const [scopes, setScopes] = useState<Scope[]>(["환경"]);
  const [scopeNotes, setScopeNotes] = useState<Record<string, string>>({ 환경: "" });
  const [scopeOther, setScopeOther] = useState("");

  const [contacts, setContacts] = useState<Contact[]>([
    { id: newId(), name: "", role: "담당", phone: "", email: "", note: "" },
  ]);

  const [notes, setNotes] = useState("");

  const selectedScopes = useMemo(() => scopes.slice(), [scopes]);

  function toggleScope(s: Scope) {
    setScopes((prev) => {
      const has = prev.includes(s);
      const next = has ? prev.filter((x) => x !== s) : [...prev, s];

      // notes map 유지/정리
      setScopeNotes((m) => {
        const nm = { ...m };
        if (!has) {
          if (!nm[s]) nm[s] = "";
        } else {
          delete nm[s];
        }
        return nm;
      });

      if (!next.includes("기타")) setScopeOther("");
      return next;
    });
  }

  function updateScopeNote(scope: Scope, text: string) {
    setScopeNotes((m) => ({ ...m, [scope]: text }));
  }

  function addContact() {
    setContacts((p) => [...p, { id: newId(), name: "", role: "담당", phone: "", email: "", note: "" }]);
  }

  function removeContact(id: string) {
    setContacts((p) => p.filter((x) => x.id !== id));
  }

  function updateContact(id: string, patch: Partial<Contact>) {
    setContacts((p) => p.map((x) => (x.id === id ? { ...x, ...patch } : x)));
  }

  function reset() {
    setName("");
    setStatus("거래중");
    setAgencyType("감독/점검");
    setAgencyTypeOther("");
    setRegion("");
    setScopes(["환경"]);
    setScopeNotes({ 환경: "" });
    setScopeOther("");
    setContacts([{ id: newId(), name: "", role: "담당", phone: "", email: "", note: "" }]);
    setNotes("");
  }

  function submit() {
    // 화면에 “필수” 표기 없이 강제
    if (!name.trim()) {
      alert("기관명을 입력하세요.");
      return;
    }
    if (!region.trim()) {
      alert("지역을 입력하세요.");
      return;
    }
    if (agencyType === "기타" && !agencyTypeOther.trim()) {
      alert("기관 유형(기타) 내용을 입력하세요.");
      return;
    }

    if (scopes.length === 0) {
      alert("업무범위를 최소 1개 선택하세요.");
      return;
    }
    if (scopes.includes("기타") && !scopeOther.trim()) {
      alert("업무범위(기타) 내용을 입력하세요.");
      return;
    }

    // 선택된 scope는 모두 한 줄 설명 필수
    for (const s of scopes) {
      const v = (scopeNotes[s] || "").trim();
      if (!v) {
        alert(`업무범위 "${s}" 설명을 입력하세요.`);
        return;
      }
    }

    const cleanContacts = contacts
      .map((c) => ({
        ...c,
        name: c.name.trim(),
        role: c.role.trim(),
        phone: c.phone.trim(),
        email: c.email.trim(),
        note: c.note.trim(),
      }))
      .filter((c) => c.name || c.phone || c.email || c.note);

    const hasAnyContact = cleanContacts.some((c) => c.phone || c.email);
    if (!hasAnyContact) {
      alert("연락처를 입력하세요.");
      return;
    }

    const now = new Date().toISOString();

    const agency: Agency = {
      id: newId(),
      name: name.trim(),
      status,
      agencyType,
      agencyTypeOther: agencyTypeOther.trim(),
      region: region.trim(),
      scopes,
      scopeNotes: Object.fromEntries(scopes.map((s) => [s, (scopeNotes[s] || "").trim()])),
      scopeOther: scopeOther.trim(),
      contacts: cleanContacts,
      notes: notes.trim(),
      createdAt: now,
      updatedAt: now,
    };

    const next = [agency, ...list];
    setList(next);
    saveAgencies(next);
    reset();
    alert("저장되었습니다.(로컬)");
  }

  function removeAgency(id: string) {
    const next = list.filter((x) => x.id !== id);
    setList(next);
    saveAgencies(next);
  }

  return (
    <div className="card">
      <h1 className="h1">관계기관 등록</h1>
      <p className="p">민원/점검/측정 결과 같은 이벤트는 나중에 “일일기록(사무)”에서 연결합니다.</p>

      <div style={{ marginTop: 14, display: "grid", gap: 10 }}>
        <div>
          <div className="p" style={{ marginTop: 0 }}>기관명</div>
          <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="예: ○○시청 ○○과" />
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>상태</div>
          <div className="row" style={{ marginTop: 8 }}>
            {(["거래중", "보류", "중단"] as const).map((s) => (
              <button key={s} type="button" className={`selBtn ${status === s ? "active" : ""}`} onClick={() => setStatus(s)}>
                {s}
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>기관 유형</div>
          <div className="row" style={{ marginTop: 8 }}>
            {TYPE_OPTIONS.map((t) => (
              <button key={t} type="button" className={`selBtn ${agencyType === t ? "active" : ""}`} onClick={() => setAgencyType(t)}>
                {t}
              </button>
            ))}
          </div>
          {agencyType === "기타" ? (
            <div style={{ marginTop: 10 }}>
              <input className="input" value={agencyTypeOther} onChange={(e) => setAgencyTypeOther(e.target.value)} placeholder="기타 유형" />
            </div>
          ) : null}
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>지역</div>
          <input className="input" value={region} onChange={(e) => setRegion(e.target.value)} placeholder="예: 대구 / 성주 / 경북" />
        </div>

        <div className="divider" />

        <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
          <div className="h1" style={{ fontSize: 15 }}>업무범위</div>
          <p className="p">선택한 항목은 아래에 설명을 입력해야 저장됩니다.</p>

          <div className="row" style={{ marginTop: 8 }}>
            {SCOPE_OPTIONS.map((s) => (
              <button key={s} type="button" className={`selBtn ${scopes.includes(s) ? "active" : ""}`} onClick={() => toggleScope(s)}>
                {s}
              </button>
            ))}
          </div>

          {scopes.includes("기타") ? (
            <div style={{ marginTop: 10 }}>
              <input className="input" value={scopeOther} onChange={(e) => setScopeOther(e.target.value)} placeholder="업무범위(기타) 내용" />
            </div>
          ) : null}

          <div style={{ marginTop: 12, display: "grid", gap: 10 }}>
            {selectedScopes.map((s) => (
              <div key={s}>
                <div className="p" style={{ marginTop: 0 }}>{s} 설명</div>
                <input
                  className="input"
                  value={scopeNotes[s] || ""}
                  onChange={(e) => updateScopeNote(s, e.target.value)}
                  placeholder="예: 대기 측정 / 전기 안전 점검 / 민원 처리 등"
                />
              </div>
            ))}
          </div>
        </div>

        <div className="divider" />

        <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
          <div className="h1" style={{ fontSize: 15 }}>연락처</div>

          {contacts.map((c) => (
            <div key={c.id} className="card" style={{ marginTop: 10, background: "rgba(255,255,255,0.02)" }}>
              <div style={{ display: "grid", gap: 10 }}>
                <input className="input" value={c.name} onChange={(e) => updateContact(c.id, { name: e.target.value })} placeholder="이름" />
                <input className="input" value={c.role} onChange={(e) => updateContact(c.id, { role: e.target.value })} placeholder="직책/부서" />
                <input className="input" value={c.phone} onChange={(e) => updateContact(c.id, { phone: e.target.value })} placeholder="전화" />
                <input className="input" value={c.email} onChange={(e) => updateContact(c.id, { email: e.target.value })} placeholder="이메일" />
                <input className="input" value={c.note} onChange={(e) => updateContact(c.id, { note: e.target.value })} placeholder="주의/고려사항" />
              </div>

              <div className="row">
                <button type="button" className="btn danger" onClick={() => removeContact(c.id)} disabled={contacts.length <= 1}>
                  삭제
                </button>
              </div>
            </div>
          ))}

          <div className="row">
            <button type="button" className="btn" onClick={addContact}>연락처 추가</button>
          </div>
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>비고</div>
          <textarea className="textarea" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="짧게(2줄)" />
        </div>
      </div>

      <div className="row">
        <button type="button" className="btn primary" onClick={submit}>
          저장(로컬)
        </button>
      </div>

      <div className="divider" />

      <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
        <div className="h1" style={{ fontSize: 15 }}>저장된 기관</div>

        {list.length === 0 ? (
          <p className="p">아직 없음</p>
        ) : (
          list.map((a) => (
            <div key={a.id} className="card" style={{ marginTop: 10, background: "rgba(255,255,255,0.02)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                <div>
                  <div style={{ fontWeight: 900 }}>{a.name}</div>
                  <div className="p" style={{ marginTop: 6 }}>
                    {a.region} · {a.agencyType === "기타" ? `기타(${a.agencyTypeOther})` : a.agencyType} · {a.status}
                  </div>
                  <div className="p" style={{ marginTop: 6 }}>
                    범위: {a.scopes.map((s) => (s === "기타" ? `기타(${a.scopeOther || "-"})` : s)).join(", ")}
                  </div>
                </div>

                <button type="button" className="btn danger" onClick={() => removeAgency(a.id)}>
                  삭제
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
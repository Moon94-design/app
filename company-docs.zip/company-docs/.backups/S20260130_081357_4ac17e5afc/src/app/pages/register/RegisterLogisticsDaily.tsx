import { useState } from "react";

/**
 * UI 요구:
 * - 1건 작성 → 저장하면 아래 리스트에 쌓이고 → 위 폼 초기화
 */

type Direction = "매입" | "출고";
type Kind = "압축품" | "분쇄품" | "펠렛";
type Item = "PP" | "PE";

type PriceRow = {
  id: string;
  direction: Direction;
  kind: Kind;
  item: Item;
  pricePerKg: number;
};

type Partner = {
  id: string;
  name: string;
  address: string;
  status: "거래중" | "보류" | "중단";
  tags: string[];
  contacts: any[];
  vehicles: any[];
  prices: PriceRow[];
  notes: string;
  createdAt: string;
  updatedAt: string;
};

type Vehicle = {
  id: string;
  vehicleNo: string;
  carrier: string;
  driverName: string;
  driverPhone: string;
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
};

type LogisticsLine = {
  id: string;
  occurredAt: string;

  partnerId: string;
  partnerName: string;

  vehicleId: string;
  vehicleNo: string;

  direction: Direction;
  kind: Kind;
  item: Item;

  qtyKg: number;
  unitPricePerKg: number;
  totalAmount: number;

  hasIssue: boolean;
  issueNote: string;
};

type DailyLogisticsLine = LogisticsLine & {
  createdAt: string;
  createdBy: string;
};

type PriceEvent = {
  eventId: string;
  occurredAt: string;
  partnerId: string;
  partnerName: string;
  vehicleNo: string;
  direction: Direction;
  kind: Kind;
  item: Item;
  unitPricePerKg: number;
  qtyKg: number;
  totalAmount: number;
  sourceDailyId: string;
};

const KEY_PARTNERS = "local_partners_v2";
const KEY_VEHICLES = "local_vehicles_v1";
const KEY_LINES = "daily_logistics_lines_v1";
const KEY_PRICE_EVENTS = "price_events_v1";
const KEY_AUTHOR = "local_author_name_v1";

function newId() {
  // @ts-ignore
  return (globalThis.crypto?.randomUUID?.() as string) || `ID_${Date.now()}_${Math.floor(Math.random() * 1e6)}`;
}

function nowIso() {
  return new Date().toISOString();
}

function loadJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function saveJson(key: string, value: any) {
  localStorage.setItem(key, JSON.stringify(value));
}

function allowedKinds(direction: Direction): Kind[] {
  return direction === "매입" ? ["압축품", "분쇄품"] : ["분쇄품", "펠렛"];
}

function defaultLine(): LogisticsLine {
  return {
    id: newId(),
    occurredAt: nowIso(),
    partnerId: "",
    partnerName: "",
    vehicleId: "",
    vehicleNo: "",
    direction: "출고",
    kind: "분쇄품",
    item: "PP",
    qtyKg: 0,
    unitPricePerKg: 0,
    totalAmount: 0,
    hasIssue: false,
    issueNote: "",
  };
}

export default function RegisterLogisticsDaily() {
  const [author, setAuthor] = useState<string>(() => localStorage.getItem(KEY_AUTHOR) || "");
  const [partners, setPartners] = useState<Partner[]>(() => loadJson(KEY_PARTNERS, [] as Partner[]));
  const vehicles = loadJson<Vehicle[]>(KEY_VEHICLES, [] as Vehicle[]);

  const [line, setLine] = useState<LogisticsLine>(() => defaultLine());
  const [savedLines, setSavedLines] = useState<DailyLogisticsLine[]>(() => loadJson(KEY_LINES, [] as DailyLogisticsLine[]));

  function recalc(next: LogisticsLine): LogisticsLine {
    const qty = Number(next.qtyKg) || 0;
    const unit = Number(next.unitPricePerKg) || 0;
    return { ...next, totalAmount: Math.round(qty * unit) };
  }

  function update(patch: Partial<LogisticsLine>) {
    setLine((prev) => {
      let next = { ...prev, ...patch };

      if (patch.direction) {
        const kinds = allowedKinds(patch.direction);
        if (!kinds.includes(next.kind)) next.kind = kinds[0];
      }

      if (patch.partnerId !== undefined) {
        const p = partners.find((pp) => pp.id === patch.partnerId);
        next.partnerName = p ? p.name : "";
      }

      if (patch.vehicleId !== undefined) {
        const v = vehicles.find((vv) => vv.id === patch.vehicleId);
        next.vehicleNo = v ? v.vehicleNo : "";
      }

      return recalc(next);
    });
  }

  function submit() {
    const by = author.trim() ? author.trim() : "작성자 미설정";
    if (!line.partnerId) {
      alert("거래처를 선택하세요.");
      return;
    }
    if (!line.vehicleNo.trim()) {
      alert("차량번호를 입력/선택하세요.");
      return;
    }
    if ((Number(line.qtyKg) || 0) <= 0) {
      alert("수량(Kg)은 0보다 커야 합니다.");
      return;
    }
    if ((Number(line.unitPricePerKg) || 0) <= 0) {
      alert("단가(원/Kg)은 0보다 커야 합니다.");
      return;
    }

    const dailyId = newId();
    const createdAt = nowIso();

    const saved: DailyLogisticsLine = {
      ...recalc({
        ...line,
        qtyKg: Number(line.qtyKg) || 0,
        unitPricePerKg: Number(line.unitPricePerKg) || 0,
      }),
      createdAt,
      createdBy: by,
    };

    const nextLines = [saved, ...savedLines];
    setSavedLines(nextLines);
    saveJson(KEY_LINES, nextLines);

    const prevEvents = loadJson<PriceEvent[]>(KEY_PRICE_EVENTS, []);
    const ev: PriceEvent = {
      eventId: newId(),
      occurredAt: saved.occurredAt,
      partnerId: saved.partnerId,
      partnerName: saved.partnerName,
      vehicleNo: saved.vehicleNo,
      direction: saved.direction,
      kind: saved.kind,
      item: saved.item,
      unitPricePerKg: saved.unitPricePerKg,
      qtyKg: saved.qtyKg,
      totalAmount: saved.totalAmount,
      sourceDailyId: dailyId,
    };
    saveJson(KEY_PRICE_EVENTS, [ev, ...prevEvents]);

    // 거래처 기준단가 자동 업데이트
    const partnersNext = partners.map((p) => {
      if (p.id !== saved.partnerId) return p;

      let nextPrices = Array.isArray(p.prices) ? [...p.prices] : [];
      const idx = nextPrices.findIndex(
        (r) => r.direction === saved.direction && r.kind === saved.kind && r.item === saved.item
      );
      if (idx >= 0) {
        nextPrices[idx] = { ...nextPrices[idx], pricePerKg: saved.unitPricePerKg };
      } else {
        nextPrices.push({
          id: newId(),
          direction: saved.direction,
          kind: saved.kind,
          item: saved.item,
          pricePerKg: saved.unitPricePerKg,
        });
      }

      return { ...p, prices: nextPrices, updatedAt: nowIso() };
    });

    setPartners(partnersNext);
    saveJson(KEY_PARTNERS, partnersNext);

    alert("저장되었습니다.(로컬) / 단가 이벤트 기록 및 거래처 단가가 업데이트되었습니다.");
    setLine(defaultLine());
  }

  const kinds = allowedKinds(line.direction);

  return (
    <div className="card">
      <h1 className="h1">유통 기록</h1>
      <p className="p">1건 작성 → 저장하면 아래 리스트에 쌓이고 → 위 폼이 초기화됩니다.</p>

      <div style={{ marginTop: 14, display: "grid", gap: 10 }}>
        <div>
          <div className="p" style={{ marginTop: 0 }}>작성자(로컬)</div>
          <input
            className="input"
            value={author}
            onChange={(e) => {
              setAuthor(e.target.value);
              localStorage.setItem(KEY_AUTHOR, e.target.value);
            }}
            placeholder="예: 홍길동"
          />
        </div>
      </div>

      <div className="divider" />

      <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
        <div className="row" style={{ justifyContent: "space-between", marginTop: 0 }}>
          <div className="pill">단위: Kg</div>
        </div>

        <div style={{ marginTop: 12, display: "grid", gap: 10 }}>
          <div>
            <div className="p" style={{ marginTop: 0 }}>거래처(필수)</div>
            <select className="input" value={line.partnerId} onChange={(e) => update({ partnerId: e.target.value })}>
              <option value="">선택</option>
              {partners.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>

          <div>
            <div className="p" style={{ marginTop: 0 }}>차량(선택)</div>
            <select className="input" value={line.vehicleId} onChange={(e) => update({ vehicleId: e.target.value })}>
              <option value="">선택</option>
              {vehicles.map((v) => (
                <option key={v.id} value={v.id}>{v.vehicleNo}</option>
              ))}
            </select>
            <div className="p" style={{ marginTop: 8, opacity: 0.9 }}>차량번호(필수)</div>
            <input className="input" value={line.vehicleNo} onChange={(e) => update({ vehicleNo: e.target.value })} placeholder="선택했으면 자동 입력됨(직접 수정 가능)" />
          </div>

          <div>
            <div className="p" style={{ marginTop: 0 }}>방향(필수)</div>
            <div className="row" style={{ marginTop: 8 }}>
              {(["매입", "출고"] as const).map((d) => (
                <button key={d} type="button" className={`selBtn ${line.direction === d ? "active" : ""}`} onClick={() => update({ direction: d })}>
                  {d}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="p" style={{ marginTop: 0 }}>종류(필수)</div>
            <div className="row" style={{ marginTop: 8 }}>
              {kinds.map((k) => (
                <button key={k} type="button" className={`selBtn ${line.kind === k ? "active" : ""}`} onClick={() => update({ kind: k })}>
                  {k}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="p" style={{ marginTop: 0 }}>품목(필수)</div>
            <div className="row" style={{ marginTop: 8 }}>
              {(["PP", "PE"] as const).map((it) => (
                <button key={it} type="button" className={`selBtn ${line.item === it ? "active" : ""}`} onClick={() => update({ item: it })}>
                  {it}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="p" style={{ marginTop: 0 }}>수량(Kg)</div>
            <input className="input" inputMode="numeric" value={String(line.qtyKg)} onChange={(e) => update({ qtyKg: Number(e.target.value || 0) })} placeholder="예: 1000" />
          </div>

          <div>
            <div className="p" style={{ marginTop: 0 }}>단가(원/Kg)</div>
            <input className="input" inputMode="numeric" value={String(line.unitPricePerKg)} onChange={(e) => update({ unitPricePerKg: Number(e.target.value || 0) })} placeholder="예: 120" />
          </div>

          <div>
            <div className="p" style={{ marginTop: 0 }}>총금액(자동)</div>
            <input className="input" value={String(line.totalAmount)} readOnly />
          </div>

          <div>
            <div className="p" style={{ marginTop: 0 }}>문제 여부</div>
            <div className="row" style={{ marginTop: 8 }}>
              <button type="button" className={`selBtn ${!line.hasIssue ? "active" : ""}`} onClick={() => update({ hasIssue: false, issueNote: "" })}>
                없음
              </button>
              <button type="button" className={`selBtn ${line.hasIssue ? "active" : ""}`} onClick={() => update({ hasIssue: true })}>
                있음
              </button>
            </div>

            {line.hasIssue ? (
              <div style={{ marginTop: 10 }}>
                <textarea className="textarea" value={line.issueNote} onChange={(e) => update({ issueNote: e.target.value })} placeholder="문제 내용 요약" />
              </div>
            ) : null}
          </div>
        </div>

        <div className="row">
          <button type="button" className="btn primary" onClick={submit}>저장(로컬)</button>
        </div>
      </div>

      <div className="divider" />

      <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
        <div className="h1" style={{ fontSize: 15 }}>저장된 유통 기록(최근 20개)</div>

        {savedLines.length === 0 ? (
          <p className="p">아직 없음</p>
        ) : (
          savedLines.slice(0, 20).map((s) => (
            <div key={s.id} className="card" style={{ marginTop: 10, background: "rgba(255,255,255,0.02)" }}>
              <div style={{ fontWeight: 900 }}>{s.partnerName}</div>
              <div className="p" style={{ marginTop: 6 }}>
                {s.occurredAt.slice(0, 19).replace("T", " ")} · 차량 {s.vehicleNo || "-"}
              </div>
              <div className="p" style={{ marginTop: 6 }}>
                {s.direction} · {s.kind} · {s.item} · {Math.round(s.unitPricePerKg).toLocaleString()}원/Kg · {Math.round(s.qtyKg).toLocaleString()}Kg
              </div>
              <div className="p" style={{ marginTop: 6 }}>
                총금액: {Math.round(s.totalAmount).toLocaleString()}
                {s.hasIssue ? " · 문제 있음" : ""}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
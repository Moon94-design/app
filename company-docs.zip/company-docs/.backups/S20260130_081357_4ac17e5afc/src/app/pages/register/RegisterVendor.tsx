import { useMemo, useState } from "react";

type Status = "거래중" | "보류" | "중단";
type Scope = "기계" | "전기" | "통신" | "소모품" | "정비" | "기타";

type Contact = {
  id: string;
  name: string;
  role: string;
  phone: string;
  note: string;
};

type Vendor = {
  id: string;
  name: string;
  status: Status;
  region: string;
  scopes: Scope[];
  otherScopeText: string; // 기타 선택 시
  contacts: Contact[];
  notes: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
};

const STORAGE_KEY = "local_vendors_v1";

function newId() {
  // @ts-ignore
  return (globalThis.crypto?.randomUUID?.() as string) || `V_${Date.now()}_${Math.floor(Math.random() * 1e6)}`;
}

function loadVendors(): Vendor[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as Vendor[];
  } catch {
    return [];
  }
}

function saveVendors(list: Vendor[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

const SCOPE_OPTIONS: Scope[] = ["기계", "전기", "통신", "소모품", "정비", "기타"];

export default function RegisterVendor() {
  const [vendors, setVendors] = useState<Vendor[]>(() => loadVendors());

  const [name, setName] = useState("");
  const [status, setStatus] = useState<Status>("거래중");
  const [region, setRegion] = useState("");
  const [scopes, setScopes] = useState<Scope[]>(["정비"]);
  const [otherScopeText, setOtherScopeText] = useState("");
  const [tagsText, setTagsText] = useState("");
  const [notes, setNotes] = useState("");

  const [contacts, setContacts] = useState<Contact[]>([
    { id: newId(), name: "", role: "담당", phone: "", note: "" },
  ]);

  const tags = useMemo(() => {
    return tagsText.split(",").map((t) => t.trim()).filter(Boolean);
  }, [tagsText]);

  function toggleScope(s: Scope) {
    setScopes((prev) => {
      const has = prev.includes(s);
      const next = has ? prev.filter((x) => x !== s) : [...prev, s];
      if (!next.includes("기타")) setOtherScopeText("");
      return next;
    });
  }

  function addContact() {
    setContacts((p) => [...p, { id: newId(), name: "", role: "담당", phone: "", note: "" }]);
  }

  function removeContact(id: string) {
    setContacts((p) => p.filter((x) => x.id !== id));
  }

  function updateContact(id: string, patch: Partial<Contact>) {
    setContacts((p) => p.map((x) => (x.id === id ? { ...x, ...patch } : x)));
  }

  function reset() {
    setName("");
    setStatus("거래중");
    setRegion("");
    setScopes(["정비"]);
    setOtherScopeText("");
    setTagsText("");
    setNotes("");
    setContacts([{ id: newId(), name: "", role: "담당", phone: "", note: "" }]);
  }

  function submit() {
    // 화면에 “필수” 표기는 안 하지만, 입력은 강제
    if (!name.trim()) {
      alert("업체명을 입력하세요.");
      return;
    }
    if (!region.trim()) {
      alert("지역을 입력하세요.");
      return;
    }
    if (scopes.length === 0) {
      alert("서비스 범위를 최소 1개 선택하세요.");
      return;
    }
    if (scopes.includes("기타") && !otherScopeText.trim()) {
      alert("기타 내용을 입력하세요.");
      return;
    }

    const cleanContacts = contacts
      .map((c) => ({
        ...c,
        name: c.name.trim(),
        role: c.role.trim(),
        phone: c.phone.trim(),
        note: c.note.trim(),
      }))
      .filter((c) => c.name || c.phone || c.note);

    const hasPhone = cleanContacts.some((c) => !!c.phone);
    if (!hasPhone) {
      alert("연락처를 입력하세요.");
      return;
    }

    const now = new Date().toISOString();

    const v: Vendor = {
      id: newId(),
      name: name.trim(),
      status,
      region: region.trim(),
      scopes,
      otherScopeText: otherScopeText.trim(),
      contacts: cleanContacts,
      notes: notes.trim(),
      tags,
      createdAt: now,
      updatedAt: now,
    };

    const next = [v, ...vendors];
    setVendors(next);
    saveVendors(next);
    reset();
    alert("저장되었습니다.(로컬)");
  }

  function removeVendor(id: string) {
    const next = vendors.filter((x) => x.id !== id);
    setVendors(next);
    saveVendors(next);
  }

  return (
    <div className="card">
      <h1 className="h1">정비/서비스 업체 등록</h1>
      <p className="p">업체 정보와 서비스 범위를 기준정보로 저장합니다.</p>

      <div style={{ marginTop: 14, display: "grid", gap: 10 }}>
        <div>
          <div className="p" style={{ marginTop: 0 }}>업체명</div>
          <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="예: OO정비" />
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>상태</div>
          <div className="row" style={{ marginTop: 8 }}>
            {(["거래중", "보류", "중단"] as const).map((s) => (
              <button key={s} type="button" className={`selBtn ${status === s ? "active" : ""}`} onClick={() => setStatus(s)}>
                {s}
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>지역</div>
          <input className="input" value={region} onChange={(e) => setRegion(e.target.value)} placeholder="예: 대구 / 성주 / 경북" />
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>서비스 범위</div>
          <div className="row" style={{ marginTop: 8 }}>
            {SCOPE_OPTIONS.map((s) => (
              <button key={s} type="button" className={`selBtn ${scopes.includes(s) ? "active" : ""}`} onClick={() => toggleScope(s)}>
                {s}
              </button>
            ))}
          </div>

          {scopes.includes("기타") ? (
            <div style={{ marginTop: 10 }}>
              <input className="input" value={otherScopeText} onChange={(e) => setOtherScopeText(e.target.value)} placeholder="기타 내용" />
            </div>
          ) : null}
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>태그(쉼표)</div>
          <input className="input" value={tagsText} onChange={(e) => setTagsText(e.target.value)} placeholder="예: 빠름,예약필수" />
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>비고</div>
          <textarea className="textarea" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="주의/고려사항" />
        </div>
      </div>

      <div className="divider" />

      <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
        <div className="h1" style={{ fontSize: 15 }}>연락처</div>

        {contacts.map((c) => (
          <div key={c.id} className="card" style={{ marginTop: 10, background: "rgba(255,255,255,0.02)" }}>
            <div style={{ display: "grid", gap: 10 }}>
              <input className="input" value={c.name} onChange={(e) => updateContact(c.id, { name: e.target.value })} placeholder="이름" />
              <input className="input" value={c.role} onChange={(e) => updateContact(c.id, { role: e.target.value })} placeholder="역할(대표/기사/AS 등)" />
              <input className="input" value={c.phone} onChange={(e) => updateContact(c.id, { phone: e.target.value })} placeholder="연락처" />
              <input className="input" value={c.note} onChange={(e) => updateContact(c.id, { note: e.target.value })} placeholder="주의/고려사항" />
            </div>

            <div className="row">
              <button type="button" className="btn danger" onClick={() => removeContact(c.id)} disabled={contacts.length <= 1}>
                삭제
              </button>
            </div>
          </div>
        ))}

        <div className="row">
          <button type="button" className="btn" onClick={addContact}>연락처 추가</button>
        </div>
      </div>

      <div className="row">
        <button type="button" className="btn primary" onClick={submit}>
          저장(로컬)
        </button>
      </div>

      <div className="divider" />

      <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
        <div className="h1" style={{ fontSize: 15 }}>저장된 업체</div>

        {vendors.length === 0 ? (
          <p className="p">아직 없음</p>
        ) : (
          vendors.map((v) => (
            <div key={v.id} className="card" style={{ marginTop: 10, background: "rgba(255,255,255,0.02)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                <div>
                  <div style={{ fontWeight: 900 }}>{v.name}</div>
                  <div className="p" style={{ marginTop: 6 }}>
                    {v.region} · {v.status}
                  </div>
                  <div className="p" style={{ marginTop: 6 }}>
                    범위: {v.scopes.map((s) => (s === "기타" ? `기타(${v.otherScopeText || "-"})` : s)).join(", ")}
                  </div>
                  {v.tags?.length ? <div className="p" style={{ marginTop: 6 }}>태그: {v.tags.join(", ")}</div> : null}
                </div>

                <button type="button" className="btn danger" onClick={() => removeVendor(v.id)}>
                  삭제
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
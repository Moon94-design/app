import { useMemo, useState } from "react";

type Vehicle = {
  id: string;
  vehicleNo: string;      // 차량번호(필수)
  carrier: string;        // 운송사(선택)
  driverName: string;     // 기사명(선택)
  driverPhone: string;    // 기사 연락처(선택)
  tags: string[];         // 태그(선택)
  notes: string;          // 비고(선택)
  createdAt: string;
  updatedAt: string;
};

const STORAGE_KEY = "local_vehicles_v1";

function newId() {
  // @ts-ignore
  return (globalThis.crypto?.randomUUID?.() as string) || `V_${Date.now()}_${Math.floor(Math.random() * 1e6)}`;
}

function loadVehicles(): Vehicle[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as Vehicle[];
  } catch {
    return [];
  }
}

function saveVehicles(list: Vehicle[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

export default function RegisterVehicle() {
  const [vehicles, setVehicles] = useState<Vehicle[]>(() => loadVehicles());

  const [vehicleNo, setVehicleNo] = useState("");
  const [carrier, setCarrier] = useState("");
  const [driverName, setDriverName] = useState("");
  const [driverPhone, setDriverPhone] = useState("");
  const [tagsText, setTagsText] = useState("");
  const [notes, setNotes] = useState("");

  const tags = useMemo(() => {
    return tagsText
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);
  }, [tagsText]);

  function resetForm() {
    setVehicleNo("");
    setCarrier("");
    setDriverName("");
    setDriverPhone("");
    setTagsText("");
    setNotes("");
  }

  function submit() {
    if (!vehicleNo.trim()) {
      alert("차량번호는 필수입니다.");
      return;
    }

    const now = new Date().toISOString();

    const v: Vehicle = {
      id: newId(),
      vehicleNo: vehicleNo.trim(),
      carrier: carrier.trim(),
      driverName: driverName.trim(),
      driverPhone: driverPhone.trim(),
      tags,
      notes: notes.trim(),
      createdAt: now,
      updatedAt: now,
    };

    const next = [v, ...vehicles];
    setVehicles(next);
    saveVehicles(next);
    resetForm();
    alert("저장되었습니다.(로컬)");
  }

  function remove(id: string) {
    const next = vehicles.filter((x) => x.id !== id);
    setVehicles(next);
    saveVehicles(next);
  }

  return (
    <div className="card">
      <h1 className="h1">차량 등록</h1>
      <p className="p">운송 리소스(차량/기사)를 기준정보로 저장합니다.</p>

      <div style={{ marginTop: 14, display: "grid", gap: 10 }}>
        <div>
          <div className="p" style={{ marginTop: 0 }}>차량번호(필수)</div>
          <input className="input" value={vehicleNo} onChange={(e) => setVehicleNo(e.target.value)} placeholder="예: 12가 3456" />
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>운송사</div>
          <input className="input" value={carrier} onChange={(e) => setCarrier(e.target.value)} placeholder="예: OO물류" />
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>기사명</div>
          <input className="input" value={driverName} onChange={(e) => setDriverName(e.target.value)} placeholder="예: 홍길동" />
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>기사 연락처</div>
          <input className="input" value={driverPhone} onChange={(e) => setDriverPhone(e.target.value)} placeholder="예: 010-0000-0000" />
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>태그(쉼표로 구분)</div>
          <input className="input" value={tagsText} onChange={(e) => setTagsText(e.target.value)} placeholder="예: 고정차량,지연주의" />
        </div>

        <div>
          <div className="p" style={{ marginTop: 0 }}>비고</div>
          <textarea className="textarea" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="주의/고려사항" />
        </div>
      </div>

      <div className="row">
        <button type="button" className="btn primary" onClick={submit}>
          저장(로컬)
        </button>
      </div>

      <div className="divider" />

      <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
        <div className="h1" style={{ fontSize: 15 }}>저장된 차량</div>
        <p className="p">다음 단계에서 거래처/출고 기록과 vehicleId로 연계합니다.</p>

        {vehicles.length === 0 ? (
          <p className="p">아직 없음</p>
        ) : (
          vehicles.map((v) => (
            <div key={v.id} className="card" style={{ marginTop: 10, background: "rgba(255,255,255,0.02)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                <div>
                  <div style={{ fontWeight: 900 }}>{v.vehicleNo}</div>
                  {v.carrier ? <div className="p" style={{ marginTop: 6 }}>운송사: {v.carrier}</div> : null}
                  {v.driverName ? <div className="p" style={{ marginTop: 6 }}>기사: {v.driverName}</div> : null}
                  {v.driverPhone ? <div className="p" style={{ marginTop: 6 }}>연락처: {v.driverPhone}</div> : null}
                  {v.tags?.length ? <div className="p" style={{ marginTop: 6 }}>태그: {v.tags.join(", ")}</div> : null}
                </div>

                <button type="button" className="btn danger" onClick={() => remove(v.id)}>
                  삭제
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

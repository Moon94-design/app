import { Link } from "react-router-dom";

export default function RegisterDaily() {
  return (
    <div className="subMenuWrap">
      <div className="subMenuGrid">
        <Link to="/register/daily/logistics" className="subMenuBtn">
          <div className="subMenuTitle">유통 기록</div>
          <ul className="subMenuList">
            <li>거래처</li>
            <li>차량번호</li>
            <li>매입/출고 · 종류 · PP/PE</li>
            <li>단가(원/Kg) · 수량(Kg)</li>
          </ul>
        </Link>

        <div className="subMenuBtn" style={{ opacity: 0.55 }}>
          <div className="subMenuTitle">생산 기록</div>
          <ul className="subMenuList"><li>다음 단계</li></ul>
        </div>

        <div className="subMenuBtn" style={{ opacity: 0.55 }}>
          <div className="subMenuTitle">사무 기록</div>
          <ul className="subMenuList"><li>다음 단계</li></ul>
        </div>

        <div className="subMenuBtn" style={{ opacity: 0.55 }}>
          <div className="subMenuTitle">회계 기록</div>
          <ul className="subMenuList"><li>다음 단계</li></ul>
        </div>
      </div>
    </div>
  );
}

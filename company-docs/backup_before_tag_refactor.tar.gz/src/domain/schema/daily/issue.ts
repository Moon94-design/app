import type { ValidationResult, Ref } from "./_common";
import { requireText, ensureString, ensureArray, newId, nowIso, todayYMD } from "./_common";

export type IssueCategory = "quality" | "equipment" | "safety";
export type IssueStatus = "진행중" | "완료";

export type IssueQuality = {
  severity: "낮음" | "보통" | "높음";
  product?: Ref; // (선택) 품목/제품 참조
  cause: string;
  action: string;
  prevent: string;
};

export type IssueEquipment = {
  equipment?: Ref; // (선택) 설비 참조
  symptom: string;
  action: string;
  prevent: string;
  status: IssueStatus;
};

export type IssueSafety = {
  risk: "낮음" | "보통" | "높음";
  location: string;
  action: string;
  prevent: string;
};

export type IssueItem = {
  id: string;
  recordDate: string;   // 어떤 날의 이슈인지
  createdAt: string;
  updatedAt: string;

  writerName: string;   // 로컬 단계: 작성자명
  title: string;
  details: string;

  category: IssueCategory;

  quality?: IssueQuality;
  equipment?: IssueEquipment;
  safety?: IssueSafety;

  tags: string[];       // 이슈 자체 태그(선택)
};

export type IssueDoc = {
  // ✅ 1계정×1일 = 1문서(그 안에 items 여러 개)
  id: string;           // stable id: ISSUE_YYYY-MM-DD_writer
  recordDate: string;
  writerName: string;
  items: IssueItem[];
  updatedAt: string;
};

export type IssueDraft = {
  recordDate: string;
  writerName: string;

  // 새 이슈 입력 폼
  category: IssueCategory;
  title: string;
  details: string;

  // category 별 필드
  q_severity: "낮음" | "보통" | "높음";
  q_cause: string;
  q_action: string;
  q_prevent: string;

  e_symptom: string;
  e_action: string;
  e_prevent: string;
  e_status: IssueStatus;

  s_risk: "낮음" | "보통" | "높음";
  s_location: string;
  s_action: string;
  s_prevent: string;
};

export function defaultIssueDraft(): IssueDraft {
  return {
    recordDate: todayYMD(),
    writerName: "",
    category: "quality",
    title: "",
    details: "",

    q_severity: "보통",
    q_cause: "",
    q_action: "",
    q_prevent: "",

    e_symptom: "",
    e_action: "",
    e_prevent: "",
    e_status: "진행중",

    s_risk: "보통",
    s_location: "",
    s_action: "",
    s_prevent: "",
  };
}

export function normalizeIssueDraft(raw: any): IssueDraft {
  const b = defaultIssueDraft();
  const cat: IssueCategory =
    raw?.category === "equipment" ? "equipment" : raw?.category === "safety" ? "safety" : "quality";

  return {
    recordDate: ensureString(raw?.recordDate, b.recordDate) || b.recordDate,
    writerName: ensureString(raw?.writerName, ""),
    category: cat,
    title: ensureString(raw?.title, ""),
    details: ensureString(raw?.details, ""),

    q_severity: raw?.q_severity === "낮음" || raw?.q_severity === "보통" || raw?.q_severity === "높음" ? raw.q_severity : "보통",
    q_cause: ensureString(raw?.q_cause, ""),
    q_action: ensureString(raw?.q_action, ""),
    q_prevent: ensureString(raw?.q_prevent, ""),

    e_symptom: ensureString(raw?.e_symptom, ""),
    e_action: ensureString(raw?.e_action, ""),
    e_prevent: ensureString(raw?.e_prevent, ""),
    e_status: raw?.e_status === "완료" ? "완료" : "진행중",

    s_risk: raw?.s_risk === "낮음" || raw?.s_risk === "보통" || raw?.s_risk === "높음" ? raw.s_risk : "보통",
    s_location: ensureString(raw?.s_location, ""),
    s_action: ensureString(raw?.s_action, ""),
    s_prevent: ensureString(raw?.s_prevent, ""),
  };
}

export function validateIssueDraft(d: IssueDraft): ValidationResult {
  const errors: any[] = [];
  requireText("recordDate", d.recordDate, "이슈 날짜를 선택하세요.", errors);
  requireText("title", d.title, "이슈 제목을 입력하세요.", errors);

  if (d.category === "quality") {
    requireText("q_action", d.q_action, "조치 내용을 입력하세요.", errors);
    requireText("q_prevent", d.q_prevent, "재발방지를 입력하세요.", errors);
  }
  if (d.category === "equipment") {
    requireText("e_symptom", d.e_symptom, "증상을 입력하세요.", errors);
    requireText("e_action", d.e_action, "조치를 입력하세요.", errors);
  }
  if (d.category === "safety") {
    requireText("s_location", d.s_location, "장소를 입력하세요.", errors);
    requireText("s_action", d.s_action, "조치를 입력하세요.", errors);
  }

  return errors.length ? { ok: false, errors } : { ok: true };
}

export function makeIssueDocId(recordDate: string, writerName: string) {
  const w = (writerName || "").trim() || "user";
  const safeW = w.replace(/[^a-zA-Z0-9가-힣_-]/g, "_").slice(0, 32);
  return `ISSUE_${recordDate}_${safeW}`;
}

export function toIssueItem(d: IssueDraft): IssueItem {
  const now = nowIso();
  const base: IssueItem = {
    id: newId("ISS"),
    recordDate: d.recordDate,
    createdAt: now,
    updatedAt: now,
    writerName: d.writerName.trim(),
    title: d.title.trim(),
    details: d.details.trim(),
    category: d.category,
    tags: [],
  };

  if (d.category === "quality") {
    base.quality = {
      severity: d.q_severity,
      cause: d.q_cause.trim(),
      action: d.q_action.trim(),
      prevent: d.q_prevent.trim(),
    };
  }
  if (d.category === "equipment") {
    base.equipment = {
      symptom: d.e_symptom.trim(),
      action: d.e_action.trim(),
      prevent: d.e_prevent.trim(),
      status: d.e_status,
    };
  }
  if (d.category === "safety") {
    base.safety = {
      risk: d.s_risk,
      location: d.s_location.trim(),
      action: d.s_action.trim(),
      prevent: d.s_prevent.trim(),
    };
  }

  return base;
}

export function normalizeIssueDoc(raw: any): IssueDoc | null {
  if (!raw || typeof raw !== "object") return null;
  const recordDate = ensureString(raw.recordDate, "");
  const writerName = ensureString(raw.writerName, "");
  if (!recordDate || !writerName) return null;

  const items = ensureArray(raw.items, []);
  return {
    id: ensureString(raw.id, makeIssueDocId(recordDate, writerName)),
    recordDate,
    writerName,
    items: items as IssueItem[],
    updatedAt: ensureString(raw.updatedAt, nowIso()),
  };
}

/**
 * IssueSafetyFields - 안전 이슈 카테고리 필드
 */
import { useMemo, useState } from "react";
import { repo } from "../../../data/repo";
import { useLinkedEntity, NONE_VALUE, type EntityOption } from "../../hooks";
import type { IssueDraft } from "../../../domain/schema/daily/issue";

type EmployeeRow = {
  id: string;
  name: string;
  branch: "대구" | "성주";
  phone: string;
  job: string;
  memo: string;
  createdAt: string;
  updatedAt: string;
};

function newId(prefix: string) {
  // @ts-ignore
  return (globalThis.crypto?.randomUUID?.() as string) || `${prefix}_${Date.now()}_${Math.floor(Math.random() * 1e6)}`;
}

type Props = {
  draft: IssueDraft;
  onUpdate: <K extends keyof IssueDraft>(key: K, value: IssueDraft[K]) => void;
};

export default function IssueSafetyFields({ draft, onUpdate }: Props) {
  const [employees, setEmployees] = useState<EmployeeRow[]>(() => repo.employees<EmployeeRow>().getAll());
  const [showEmpForm, setShowEmpForm] = useState(false);
  const [empDraft, setEmpDraft] = useState({
    name: "",
    branch: "대구" as "대구" | "성주",
    phone: "",
    job: "",
    memo: "",
  });

  const empOptions: EntityOption[] = useMemo(
    () => employees.map((e) => ({ id: e.id, label: e.name, subLabel: e.job })),
    [employees]
  );

  const empEntity = useLinkedEntity({
    options: empOptions,
    fieldName: "직원",
    required: false,
    initialId: draft.s_employeeId,
    initialLabel: draft.s_employeeLabel,
  });

  // Draft와 동기화
  const handleEmpSelect = (id: string, label: string) => {
    empEntity.select(id, label);
    onUpdate("s_employeeId", id);
    onUpdate("s_employeeLabel", label);
  };

  function submitEmp() {
    const name = empDraft.name.trim();
    if (!name) return alert("이름을 입력하세요.");
    if (!empDraft.phone.trim()) return alert("연락처를 입력하세요.");
    if (!empDraft.job.trim()) return alert("직무를 입력하세요.");

    const now = new Date().toISOString();
    const row: EmployeeRow = {
      id: newId("EMP"),
      name,
      branch: empDraft.branch,
      phone: empDraft.phone.trim(),
      job: empDraft.job.trim(),
      memo: empDraft.memo.trim(),
      createdAt: now,
      updatedAt: now,
    };

    const next = [row, ...employees];
    setEmployees(next);
    repo.employees<EmployeeRow>().setAll(next);

    handleEmpSelect(row.id, row.name);
    setShowEmpForm(false);
    setEmpDraft({ name: "", branch: "대구", phone: "", job: "", memo: "" });
    alert("직원이 추가되었습니다.");
  }

  return (
    <>
      {/* 직원 선택 */}
      <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
        <div className="p">직원</div>
        <div style={{ display: "grid", gap: 8 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr auto auto", gap: 8, alignItems: "center" }}>
            <div style={{ position: "relative" }}>
              <input
                className="input"
                value={empEntity.searchInput}
                onChange={(e) => empEntity.handleSearchChange(e.target.value)}
                onFocus={empEntity.handleFocus}
                onBlur={empEntity.handleBlur}
                placeholder="직원명 검색 또는 선택"
              />
              {empEntity.showSuggestions && empEntity.filteredOptions.length > 0 && (
                <div
                  style={{
                    position: "absolute",
                    top: "100%",
                    left: 0,
                    right: 0,
                    background: "var(--bg-card, #222)",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: 8,
                    maxHeight: 200,
                    overflow: "auto",
                    zIndex: 100,
                  }}
                >
                  {empEntity.filteredOptions.map((o) => (
                    <div
                      key={o.id}
                      style={{
                        padding: "8px 12px",
                        cursor: "pointer",
                        borderBottom: "1px solid rgba(255,255,255,0.05)",
                      }}
                      onClick={() => {
                        empEntity.selectFromSuggestion(o);
                        onUpdate("s_employeeId", o.id);
                        onUpdate("s_employeeLabel", o.label);
                      }}
                      onMouseDown={(e) => e.preventDefault()}
                    >
                      {o.label} {o.subLabel && <span style={{ opacity: 0.5 }}>· {o.subLabel}</span>}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <select
              className="input"
              value={draft.s_employeeId || ""}
              onChange={(e) => {
                const id = e.target.value;
                if (id === NONE_VALUE) {
                  handleEmpSelect(NONE_VALUE, "");
                } else if (id) {
                  const found = empOptions.find((o) => o.id === id);
                  handleEmpSelect(id, found?.label || "");
                } else {
                  handleEmpSelect("", "");
                }
              }}
              style={{ width: 120 }}
            >
              <option value="">▼ 선택</option>
              <option value={NONE_VALUE}>해당없음</option>
              {empOptions.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.label} ({o.subLabel})
                </option>
              ))}
            </select>
            <button type="button" className="btn" onClick={() => setShowEmpForm((v) => !v)}>
              {showEmpForm ? "닫기" : "추가"}
            </button>
          </div>
          {draft.s_employeeLabel && draft.s_employeeId !== NONE_VALUE && (
            <div style={{ fontSize: 12, opacity: 0.7 }}>선택됨: {draft.s_employeeLabel}</div>
          )}
          {draft.s_employeeId === NONE_VALUE && <div style={{ fontSize: 12, opacity: 0.7 }}>해당없음</div>}
        </div>
      </div>

      {/* 직원 인라인 추가 폼 */}
      {showEmpForm && (
        <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
          <div style={{ display: "grid", gap: 8 }}>
            <div>
              <div className="p" style={{ marginTop: 0 }}>
                이름 *
              </div>
              <input
                className="input"
                value={empDraft.name}
                onChange={(e) => setEmpDraft({ ...empDraft, name: e.target.value })}
              />
            </div>
            <div>
              <div className="p" style={{ marginTop: 0 }}>
                지부
              </div>
              <div className="row" style={{ marginTop: 8 }}>
                {(["대구", "성주"] as const).map((b) => (
                  <button
                    key={b}
                    type="button"
                    className={`selBtn ${empDraft.branch === b ? "active" : ""}`}
                    onClick={() => setEmpDraft({ ...empDraft, branch: b })}
                  >
                    {b}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div className="p" style={{ marginTop: 0 }}>
                연락처 *
              </div>
              <input
                className="input"
                value={empDraft.phone}
                onChange={(e) => setEmpDraft({ ...empDraft, phone: e.target.value })}
              />
            </div>
            <div>
              <div className="p" style={{ marginTop: 0 }}>
                직무 *
              </div>
              <input
                className="input"
                value={empDraft.job}
                onChange={(e) => setEmpDraft({ ...empDraft, job: e.target.value })}
              />
            </div>
            <div className="row">
              <button type="button" className="btn primary" onClick={submitEmp}>
                저장
              </button>
              <button type="button" className="btn" onClick={() => setShowEmpForm(false)}>
                취소
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 위험도 */}
      <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
        <div className="p">위험도</div>
        <div className="row" style={{ marginTop: 0 }}>
          {(["낮음", "보통", "높음"] as const).map((risk) => (
            <button
              key={risk}
              type="button"
              className={`selBtn ${draft.s_risk === risk ? "active" : ""}`}
              onClick={() => onUpdate("s_risk", risk)}
            >
              {risk}
            </button>
          ))}
        </div>
      </div>

      {/* 장소 */}
      <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
        <div className="p">장소</div>
        <input
          className="input"
          value={draft.s_location}
          onChange={(e) => onUpdate("s_location", e.target.value)}
        />
      </div>

      {/* 조치 */}
      <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
        <div className="p">조치</div>
        <textarea
          className="textarea"
          rows={2}
          value={draft.s_action}
          onChange={(e) => onUpdate("s_action", e.target.value)}
        />
      </div>

      {/* 재발방지 */}
      <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
        <div className="p">재발방지</div>
        <textarea
          className="textarea"
          rows={2}
          value={draft.s_prevent}
          onChange={(e) => onUpdate("s_prevent", e.target.value)}
        />
      </div>
    </>
  );
}

/**
 * ActionForm - 조치 기록 폼 컴포넌트 (범용)
 * 
 * 사용처:
 * - RegisterAction 페이지
 * - IssueForm에서 해결완료 시 인라인 조치 입력
 * 
 * Props:
 * - recordDate: 기록일
 * - writerName, writerRole: 작성자 정보
 * - linkedIssue: 연계된 이슈 정보 (이슈에서 호출 시)
 * - category: 이슈 분류 (품질/설비/안전)
 * - onSubmit: 저장 콜백
 * - onCancel: 취소 콜백
 * - embedded: 다른 페이지에 삽입된 경우
 */
import { useEffect, useMemo, useState } from "react";
import { repo } from "../../../data/repo";
import TagInputText from "../TagInputText";
import { ConfirmedTagChips, SuggestionItem } from "../TagWidgets";
import { formatPhoneInput } from "../../utils/phone";
import { useAutoTitle, useTagSuggestion, useLinkedEntity, validateFields, NONE_VALUE, type EntityOption } from "../../hooks";
import { defaultActionDraft, toActionItem, type ActionDraft, type ActionItem } from "../../../domain/schema/daily/action";
import type { IssueCategory } from "../../../domain/schema/daily/issue";

type VendorRow = {
  id: string;
  name: string;
  status: "거래중" | "보류" | "중단";
  region: string;
  scopes: string[];
  otherScopeText: string;
  contacts: Array<{ id: string; name: string; role: string; phone: string; note: string }>;
  notes: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
};

function newId(prefix: string) {
  // @ts-ignore
  return (globalThis.crypto?.randomUUID?.() as string) || `${prefix}_${Date.now()}_${Math.floor(Math.random() * 1e6)}`;
}

const SCOPE_OPTIONS = ["기계", "전기", "통신", "소모품", "정비", "기타"] as const;
type Scope = (typeof SCOPE_OPTIONS)[number];

export type ActionFormProps = {
  recordDate: string;
  writerName: string;
  writerRole: string;
  site?: "대구" | "성주";
  onSubmit: (item: ActionItem, draft: ActionDraft) => void;
  onCancel?: () => void;
  embedded?: boolean;
  // 이슈에서 호출 시 연계 정보
  linkedIssue?: {
    id: string;
    title: string;
  };
  category?: IssueCategory;
  // 진행중 이슈 목록 (선택용)
  pendingIssues?: Array<{ id: string; title: string; category: string; date: string }>;
};

export default function ActionForm({
  recordDate,
  writerName,
  writerRole,
  site,
  onSubmit,
  onCancel,
  embedded = false,
  linkedIssue,
  category,
  pendingIssues = [],
}: ActionFormProps) {
  const [draft, setDraft] = useState<ActionDraft>(() => ({
    ...defaultActionDraft(),
    recordDate,
    writerName,
    writerRole,
    site,
    issueId: linkedIssue?.id || "",
    issueLabel: linkedIssue?.title || "",
  }));

  // 제목 자동 생성
  const categoryLabel = category === "quality" ? "품질" : category === "equipment" ? "설비" : category === "safety" ? "안전" : "";
  const autoTitle = useAutoTitle({
    recordDate,
    writerName,
    writerRole,
    category: categoryLabel,
    suffix: "조치기록",
  });

  // Draft에 제목 동기화
  useEffect(() => {
    setDraft((prev) => ({ ...prev, title: autoTitle.title }));
  }, [autoTitle.title]);

  // 태그 추천
  const tagSuggestion = useTagSuggestion({
    scope: "action",
    tagsText: draft.tagsText || "",
    onTagsChange: (text) => setDraft((prev) => ({ ...prev, tagsText: text })),
    contentText: draft.details || "",
  });

  // 기준정보 로드
  const [vendors, setVendors] = useState<VendorRow[]>(() => repo.vendors<VendorRow>().getAll());

  // 이슈 연계 옵션 (진행중 이슈만)
  const issueOptions: EntityOption[] = useMemo(
    () => pendingIssues.map((i) => ({ id: i.id, label: i.title, subLabel: `${i.date} · ${i.category}` })),
    [pendingIssues]
  );

  // 업체 연계 옵션
  const vendorOptions: EntityOption[] = useMemo(
    () => vendors.map((v) => ({ id: v.id, label: v.name, subLabel: `${v.region} · ${v.scopes.join(", ")}` })),
    [vendors]
  );

  // 이슈 연계 (linkedIssue가 있으면 고정)
  const issueEntity = useLinkedEntity({
    options: issueOptions,
    fieldName: "이슈",
    required: false,
    initialId: linkedIssue?.id || "",
    initialLabel: linkedIssue?.title || "",
  });

  // 업체 연계
  const vendorEntity = useLinkedEntity({
    options: vendorOptions,
    fieldName: "업체",
    required: false,
  });

  // 외부 props 변경 시 동기화
  useEffect(() => {
    setDraft((prev) => ({
      ...prev,
      recordDate,
      writerName,
      writerRole,
      site,
    }));
  }, [recordDate, writerName, writerRole, site]);

  // 업체 인라인 추가 폼
  const [showVendorForm, setShowVendorForm] = useState(false);
  const [vendorDraft, setVendorDraft] = useState({
    name: "",
    status: "거래중" as "거래중" | "보류" | "중단",
    region: "",
    scopes: ["정비"] as Scope[],
    otherScopeText: "",
    contacts: [{ id: newId("C"), name: "", role: "담당", phone: "", note: "" }],
    notes: "",
    tagsText: "",
  });

  function resetVendorDraft() {
    setVendorDraft({
      name: "",
      status: "거래중",
      region: "",
      scopes: ["정비"],
      otherScopeText: "",
      contacts: [{ id: newId("C"), name: "", role: "담당", phone: "", note: "" }],
      notes: "",
      tagsText: "",
    });
  }

  function toggleScope(s: Scope) {
    const has = vendorDraft.scopes.includes(s);
    const nextScopes = has ? vendorDraft.scopes.filter((x) => x !== s) : [...vendorDraft.scopes, s];
    const next = { ...vendorDraft, scopes: nextScopes };
    if (!nextScopes.includes("기타")) next.otherScopeText = "";
    setVendorDraft(next);
  }

  function addContact() {
    setVendorDraft({
      ...vendorDraft,
      contacts: [...vendorDraft.contacts, { id: newId("C"), name: "", role: "담당", phone: "", note: "" }],
    });
  }

  function removeContact(id: string) {
    const next = vendorDraft.contacts.filter((c) => c.id !== id);
    if (next.length === 0) next.push({ id: newId("C"), name: "", role: "담당", phone: "", note: "" });
    setVendorDraft({ ...vendorDraft, contacts: next });
  }

  function updateContact(id: string, patch: Partial<{ name: string; role: string; phone: string; note: string }>) {
    setVendorDraft({
      ...vendorDraft,
      contacts: vendorDraft.contacts.map((c) => (c.id === id ? { ...c, ...patch } : c)),
    });
  }

  function submitVendor() {
    if (!vendorDraft.name.trim()) return alert("업체명을 입력하세요.");
    if (!vendorDraft.region.trim()) return alert("지역을 입력하세요.");
    if (vendorDraft.scopes.length === 0) return alert("서비스 범위를 최소 1개 선택하세요.");
    if (vendorDraft.scopes.includes("기타") && !vendorDraft.otherScopeText.trim()) return alert("기타 내용을 입력하세요.");

    const cleanContacts = vendorDraft.contacts
      .filter((c) => c.name.trim() || c.phone.trim())
      .map((c) => ({ ...c, name: c.name.trim(), phone: c.phone.trim(), role: c.role.trim(), note: c.note.trim() }));

    const now = new Date().toISOString();
    const tags = (vendorDraft.tagsText || "").split(",").map((t) => t.trim()).filter(Boolean);

    const row: VendorRow = {
      id: newId("V"),
      name: vendorDraft.name.trim(),
      status: vendorDraft.status,
      region: vendorDraft.region.trim(),
      scopes: vendorDraft.scopes,
      otherScopeText: vendorDraft.otherScopeText.trim(),
      contacts: cleanContacts.length ? cleanContacts : [{ id: newId("C"), name: "", role: "담당", phone: "", note: "" }],
      notes: vendorDraft.notes.trim(),
      tags,
      createdAt: now,
      updatedAt: now,
    };

    const next = [row, ...vendors];
    setVendors(next);
    repo.vendors<VendorRow>().setAll(next);

    // 자동 선택
    vendorEntity.select(row.id, row.name);
    setDraft((p) => ({ ...p, vendorId: row.id, vendorLabel: row.name }));
    resetVendorDraft();
    setShowVendorForm(false);
    alert("업체가 추가되었습니다.");
  }

  // 저장
  function handleSubmit() {
    // 필수 필드 검증
    const validation = validateFields(
      {
        writerName,
        writerRole,
        title: autoTitle.title,
        details: draft.details,
      },
      [
        { name: "writerName", label: "작성자", required: true },
        { name: "writerRole", label: "직책", required: true },
        { name: "title", label: "제목", required: true },
        { name: "details", label: "내용", required: true },
      ]
    );

    if (!validation.ok) {
      return alert(validation.firstError);
    }

    // 태그 bump
    tagSuggestion.bumpAllTags();

    // 최종 Draft 구성
    const finalDraft: ActionDraft = {
      ...draft,
      recordDate,
      writerName,
      writerRole,
      title: autoTitle.title,
      site,
      issueId: linkedIssue?.id || issueEntity.selectedId || "",
      issueLabel: linkedIssue?.title || issueEntity.selectedLabel || "",
      vendorId: vendorEntity.selectedId || "",
      vendorLabel: vendorEntity.selectedLabel || "",
    };

    const item = toActionItem(finalDraft);
    onSubmit(item, finalDraft);

    // 리셋
    setDraft({
      ...defaultActionDraft(),
      recordDate,
      writerName,
      writerRole,
      site,
    });
    autoTitle.resetTitle();
    issueEntity.reset();
    vendorEntity.reset();
  }

  // 리셋
  function handleReset() {
    setDraft({
      ...defaultActionDraft(),
      recordDate,
      writerName,
      writerRole,
      site,
    });
    autoTitle.resetTitle();
    issueEntity.reset();
    vendorEntity.reset();
    onCancel?.();
  }

  // 해당없음 선택 시 금액 숨김
  const showCostField = vendorEntity.selectedId && vendorEntity.selectedId !== NONE_VALUE;

  return (
    <div className={embedded ? "" : "card"}>
      <div style={{ display: "grid", gap: 8 }}>
        {/* 제목 */}
        <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
          <div className="p">제목 *</div>
          <input
            className="input"
            value={autoTitle.title}
            onFocus={autoTitle.onTitleFocus}
            onChange={(e) => autoTitle.setTitle(e.target.value)}
            placeholder="클릭하면 자동완성"
          />
        </div>

        {/* 이슈 연계 - linkedIssue가 있으면 고정 표시, 없으면 선택 가능 */}
        {linkedIssue ? (
          <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
            <div className="p">연계 이슈</div>
            <div style={{ padding: "8px 12px", background: "rgba(70,130,255,0.1)", borderRadius: 8 }}>
              {linkedIssue.title}
            </div>
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
            <div className="p">이슈 연계</div>
            <div style={{ display: "grid", gap: 8 }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 8, alignItems: "center" }}>
                <div style={{ position: "relative" }}>
                  <input
                    className="input"
                    value={issueEntity.searchInput}
                    onChange={(e) => issueEntity.handleSearchChange(e.target.value)}
                    onFocus={issueEntity.handleFocus}
                    onBlur={issueEntity.handleBlur}
                    placeholder="진행중 이슈 검색 또는 선택"
                  />
                  {issueEntity.showSuggestions && issueEntity.filteredOptions.length > 0 && (
                    <div
                      style={{
                        position: "absolute",
                        top: "100%",
                        left: 0,
                        right: 0,
                        background: "var(--bg-card, #222)",
                        border: "1px solid rgba(255,255,255,0.1)",
                        borderRadius: 8,
                        maxHeight: 200,
                        overflow: "auto",
                        zIndex: 100,
                      }}
                    >
                      {issueEntity.filteredOptions.map((o) => (
                        <div
                          key={o.id}
                          style={{
                            padding: "8px 12px",
                            cursor: "pointer",
                            borderBottom: "1px solid rgba(255,255,255,0.05)",
                          }}
                          onClick={() => {
                            issueEntity.selectFromSuggestion(o);
                            setDraft((p) => ({ ...p, issueId: o.id, issueLabel: o.label }));
                          }}
                          onMouseDown={(e) => e.preventDefault()}
                        >
                          {o.label} {o.subLabel && <span style={{ opacity: 0.5 }}>· {o.subLabel}</span>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <select
                  className="input"
                  value={issueEntity.selectedId}
                  onChange={(e) => {
                    issueEntity.selectFromDropdown(e.target.value);
                    const found = issueOptions.find((o) => o.id === e.target.value);
                    setDraft((p) => ({ ...p, issueId: e.target.value, issueLabel: found?.label || "" }));
                  }}
                  style={{ width: 140 }}
                >
                  <option value="">▼ 선택</option>
                  <option value={NONE_VALUE}>해당없음</option>
                  {issueOptions.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </div>
              {issueEntity.selectedLabel && issueEntity.selectedId !== NONE_VALUE && (
                <div style={{ fontSize: 12, opacity: 0.7 }}>선택됨: {issueEntity.selectedLabel}</div>
              )}
              {issueEntity.selectedId === NONE_VALUE && (
                <div style={{ fontSize: 12, opacity: 0.7 }}>해당없음</div>
              )}
              {pendingIssues.length === 0 && !linkedIssue && (
                <div style={{ fontSize: 12, opacity: 0.5, color: "#888" }}>진행중인 이슈가 없습니다</div>
              )}
            </div>
          </div>
        )}

        {/* 내용 */}
        <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
          <div className="p">내용 *</div>
          <textarea
            className="textarea"
            rows={4}
            value={draft.details}
            onChange={(e) => setDraft((p) => ({ ...p, details: e.target.value }))}
          />
        </div>

        {/* 추천 태그 */}
        {tagSuggestion.visibleSuggestions.length > 0 && (
          <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
            <div className="p">추천 태그</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}>
              {tagSuggestion.visibleSuggestions.map((s) => (
                <SuggestionItem
                  key={`${s.source}:${s.tag}`}
                  s={s}
                  onApply={tagSuggestion.applySuggestion}
                  onDismiss={tagSuggestion.dismissSuggestion}
                  compact
                />
              ))}
              {tagSuggestion.allSuggestions.length > 5 && (
                <button type="button" className="btn" onClick={() => tagSuggestion.setShowAll((v) => !v)}>
                  {tagSuggestion.showAll ? "접기" : `더보기(${tagSuggestion.allSuggestions.length})`}
                </button>
              )}
            </div>
          </div>
        )}

        {/* 태그 */}
        <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
          <div className="p">태그</div>
          <div>
            <ConfirmedTagChips
              tagsText={draft.tagsText}
              onRemove={tagSuggestion.removeTag}
              compact
              getTone={tagSuggestion.getTone}
            />
            <TagInputText
              value={draft.tagsText}
              onChange={(text) => setDraft((p) => ({ ...p, tagsText: text }))}
              scope="action"
              showChips={false}
            />
          </div>
        </div>

        {/* 업체명 연계 */}
        <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
          <div className="p">업체명</div>
          <div style={{ display: "grid", gap: 8 }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr auto auto", gap: 8, alignItems: "center" }}>
              <div style={{ position: "relative" }}>
                <input
                  className="input"
                  value={vendorEntity.searchInput}
                  onChange={(e) => vendorEntity.handleSearchChange(e.target.value)}
                  onFocus={vendorEntity.handleFocus}
                  onBlur={vendorEntity.handleBlur}
                  placeholder="업체명 검색 또는 선택"
                />
                {vendorEntity.showSuggestions && vendorEntity.filteredOptions.length > 0 && (
                  <div
                    style={{
                      position: "absolute",
                      top: "100%",
                      left: 0,
                      right: 0,
                      background: "var(--bg-card, #222)",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: 8,
                      maxHeight: 200,
                      overflow: "auto",
                      zIndex: 100,
                    }}
                  >
                    {vendorEntity.filteredOptions.map((o) => (
                      <div
                        key={o.id}
                        style={{
                          padding: "8px 12px",
                          cursor: "pointer",
                          borderBottom: "1px solid rgba(255,255,255,0.05)",
                        }}
                        onClick={() => {
                          vendorEntity.selectFromSuggestion(o);
                          setDraft((p) => ({ ...p, vendorId: o.id, vendorLabel: o.label }));
                        }}
                        onMouseDown={(e) => e.preventDefault()}
                      >
                        {o.label} {o.subLabel && <span style={{ opacity: 0.5 }}>· {o.subLabel}</span>}
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <select
                className="input"
                value={vendorEntity.selectedId}
                onChange={(e) => {
                  vendorEntity.selectFromDropdown(e.target.value);
                  const found = vendorOptions.find((o) => o.id === e.target.value);
                  setDraft((p) => ({
                    ...p,
                    vendorId: e.target.value,
                    vendorLabel: found?.label || "",
                    vendorCost: e.target.value === NONE_VALUE ? 0 : p.vendorCost,
                  }));
                }}
                style={{ width: 120 }}
              >
                <option value="">▼ 선택</option>
                <option value={NONE_VALUE}>해당없음</option>
                {vendorOptions.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.label}
                  </option>
                ))}
              </select>
              <button type="button" className="btn" onClick={() => setShowVendorForm((v) => !v)}>
                {showVendorForm ? "닫기" : "추가"}
              </button>
            </div>
            {vendorEntity.selectedLabel && vendorEntity.selectedId !== NONE_VALUE && (
              <div style={{ fontSize: 12, opacity: 0.7 }}>선택됨: {vendorEntity.selectedLabel}</div>
            )}
            {vendorEntity.selectedId === NONE_VALUE && (
              <div style={{ fontSize: 12, opacity: 0.7 }}>해당없음</div>
            )}
          </div>
        </div>

        {/* 업체 인라인 추가 폼 */}
        {showVendorForm && (
          <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
            <div style={{ display: "grid", gap: 8 }}>
              <div>
                <div className="p" style={{ marginTop: 0 }}>
                  업체명 *
                </div>
                <input
                  className="input"
                  value={vendorDraft.name}
                  onChange={(e) => setVendorDraft({ ...vendorDraft, name: e.target.value })}
                />
              </div>

              <div>
                <div className="p" style={{ marginTop: 0 }}>
                  상태
                </div>
                <div className="row" style={{ marginTop: 8 }}>
                  {(["거래중", "보류", "중단"] as const).map((st) => (
                    <button
                      key={st}
                      type="button"
                      className={`selBtn ${vendorDraft.status === st ? "active" : ""}`}
                      onClick={() => setVendorDraft({ ...vendorDraft, status: st })}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="p" style={{ marginTop: 0 }}>
                  지역 *
                </div>
                <input
                  className="input"
                  value={vendorDraft.region}
                  onChange={(e) => setVendorDraft({ ...vendorDraft, region: e.target.value })}
                  placeholder="예: 대구, 경북"
                />
              </div>

              <div>
                <div className="p" style={{ marginTop: 0 }}>
                  서비스 범위
                </div>
                <div className="row" style={{ marginTop: 8, flexWrap: "wrap" }}>
                  {SCOPE_OPTIONS.map((sc) => (
                    <button
                      key={sc}
                      type="button"
                      className={`selBtn ${vendorDraft.scopes.includes(sc) ? "active" : ""}`}
                      onClick={() => toggleScope(sc)}
                    >
                      {sc}
                    </button>
                  ))}
                </div>
                {vendorDraft.scopes.includes("기타") && (
                  <input
                    className="input"
                    style={{ marginTop: 8 }}
                    value={vendorDraft.otherScopeText}
                    onChange={(e) => setVendorDraft({ ...vendorDraft, otherScopeText: e.target.value })}
                    placeholder="기타 내용"
                  />
                )}
              </div>

              <div>
                <div className="p" style={{ marginTop: 0 }}>
                  담당자
                </div>
                {vendorDraft.contacts.map((c, idx) => (
                  <div
                    key={c.id}
                    style={{
                      display: "grid",
                      gridTemplateColumns: "1fr 1fr 1fr auto",
                      gap: 8,
                      marginTop: idx === 0 ? 8 : 4,
                    }}
                  >
                    <input
                      className="input"
                      value={c.name}
                      onChange={(e) => updateContact(c.id, { name: e.target.value })}
                      placeholder="이름"
                    />
                    <input
                      className="input"
                      value={c.role}
                      onChange={(e) => updateContact(c.id, { role: e.target.value })}
                      placeholder="역할"
                    />
                    <input
                      className="input"
                      value={c.phone}
                      onChange={(e) => updateContact(c.id, { phone: formatPhoneInput(e.target.value) })}
                      placeholder="연락처"
                    />
                    <button type="button" className="btn danger" onClick={() => removeContact(c.id)}>
                      삭제
                    </button>
                  </div>
                ))}
                <button type="button" className="btn" style={{ marginTop: 8 }} onClick={addContact}>
                  담당자 추가
                </button>
              </div>

              <div>
                <div className="p" style={{ marginTop: 0 }}>
                  비고
                </div>
                <textarea
                  className="textarea"
                  rows={2}
                  value={vendorDraft.notes}
                  onChange={(e) => setVendorDraft({ ...vendorDraft, notes: e.target.value })}
                />
              </div>

              <div className="row">
                <button type="button" className="btn primary" onClick={submitVendor}>
                  저장
                </button>
                <button
                  type="button"
                  className="btn"
                  onClick={() => {
                    resetVendorDraft();
                    setShowVendorForm(false);
                  }}
                >
                  취소
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 금액 - 업체 선택 시에만 표시 (해당없음 제외) */}
        {showCostField && (
          <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
            <div className="p">금액</div>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <input
                className="input"
                inputMode="numeric"
                value={draft.vendorCost || ""}
                onChange={(e) =>
                  setDraft((p) => ({
                    ...p,
                    vendorCost: Number(e.target.value.replace(/[^0-9]/g, "")) || 0,
                  }))
                }
                placeholder="0"
                style={{ width: 150 }}
              />
              <span style={{ opacity: 0.7 }}>원</span>
            </div>
          </div>
        )}

        {/* 버튼 */}
        <div className="row">
          <button type="button" className="btn primary" onClick={handleSubmit}>
            저장
          </button>
          <button type="button" className="btn" onClick={handleReset}>
            {onCancel ? "취소" : "초기화"}
          </button>
        </div>
      </div>
    </div>
  );
}

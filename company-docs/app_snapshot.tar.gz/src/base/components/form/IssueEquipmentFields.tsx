/**
 * IssueEquipmentFields - 설비 이슈 카테고리 필드
 */
import { useMemo, useState } from "react";
import { repo } from "../../../data/repo";
import { useLinkedEntity, NONE_VALUE, type EntityOption } from "../../hooks";
import type { IssueDraft } from "../../../domain/schema/daily/issue";

type EquipmentRow = {
  id: string;
  name: string;
  location: string;
  equipType: string;
  equipTypeNote: string;
  importance: string;
  makerModel: string;
  installedAt: string;
  inspectCycle: string;
  inspectNote: string;
  consumableIds: string[];
  createdAt: string;
  updatedAt: string;
};

function newId(prefix: string) {
  // @ts-ignore
  return (globalThis.crypto?.randomUUID?.() as string) || `${prefix}_${Date.now()}_${Math.floor(Math.random() * 1e6)}`;
}

type Props = {
  draft: IssueDraft;
  onUpdate: <K extends keyof IssueDraft>(key: K, value: IssueDraft[K]) => void;
};

export default function IssueEquipmentFields({ draft, onUpdate }: Props) {
  const [equipments, setEquipments] = useState<EquipmentRow[]>(() => repo.equipments<EquipmentRow>().getAll());
  const [showEquipForm, setShowEquipForm] = useState(false);
  const [equipDraft, setEquipDraft] = useState({
    name: "",
    location: "",
    equipType: "생산설비",
    equipTypeNote: "",
    importance: "중",
    makerModel: "",
    installedAt: "",
    inspectCycle: "월간",
    inspectNote: "",
  });

  const equipOptions: EntityOption[] = useMemo(
    () => equipments.map((e) => ({ id: e.id, label: e.name, subLabel: e.location })),
    [equipments]
  );

  const equipEntity = useLinkedEntity({
    options: equipOptions,
    fieldName: "설비",
    required: false,
    initialId: draft.e_equipmentId,
    initialLabel: draft.e_equipmentLabel,
  });

  // Draft와 동기화
  const handleEquipSelect = (id: string, label: string) => {
    equipEntity.select(id, label);
    onUpdate("e_equipmentId", id);
    onUpdate("e_equipmentLabel", label);
  };

  function submitEquip() {
    const name = equipDraft.name.trim();
    const location = equipDraft.location.trim();
    if (!name) return alert("설비명을 입력하세요.");
    if (!location) return alert("설치 위치를 입력하세요.");

    const now = new Date().toISOString();
    const row: EquipmentRow = {
      id: newId("EQ"),
      name,
      location,
      equipType: equipDraft.equipType,
      equipTypeNote: equipDraft.equipTypeNote.trim(),
      importance: equipDraft.importance,
      makerModel: equipDraft.makerModel.trim(),
      installedAt: equipDraft.installedAt.trim(),
      inspectCycle: equipDraft.inspectCycle,
      inspectNote: equipDraft.inspectNote.trim(),
      consumableIds: [],
      createdAt: now,
      updatedAt: now,
    };

    const next = [row, ...equipments];
    setEquipments(next);
    repo.equipments<EquipmentRow>().setAll(next);

    // 자동 선택
    handleEquipSelect(row.id, row.name);
    setShowEquipForm(false);
    setEquipDraft({
      name: "",
      location: "",
      equipType: "생산설비",
      equipTypeNote: "",
      importance: "중",
      makerModel: "",
      installedAt: "",
      inspectCycle: "월간",
      inspectNote: "",
    });
    alert("설비가 추가되었습니다.");
  }

  return (
    <>
      {/* 설비 선택 */}
      <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
        <div className="p">설비</div>
        <div style={{ display: "grid", gap: 8 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr auto auto", gap: 8, alignItems: "center" }}>
            <div style={{ position: "relative" }}>
              <input
                className="input"
                value={equipEntity.searchInput}
                onChange={(e) => equipEntity.handleSearchChange(e.target.value)}
                onFocus={equipEntity.handleFocus}
                onBlur={equipEntity.handleBlur}
                placeholder="설비명 검색 또는 선택"
              />
              {equipEntity.showSuggestions && equipEntity.filteredOptions.length > 0 && (
                <div
                  style={{
                    position: "absolute",
                    top: "100%",
                    left: 0,
                    right: 0,
                    background: "var(--bg-card, #222)",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: 8,
                    maxHeight: 200,
                    overflow: "auto",
                    zIndex: 100,
                  }}
                >
                  {equipEntity.filteredOptions.map((o) => (
                    <div
                      key={o.id}
                      style={{
                        padding: "8px 12px",
                        cursor: "pointer",
                        borderBottom: "1px solid rgba(255,255,255,0.05)",
                      }}
                      onClick={() => {
                        equipEntity.selectFromSuggestion(o);
                        onUpdate("e_equipmentId", o.id);
                        onUpdate("e_equipmentLabel", o.label);
                      }}
                      onMouseDown={(e) => e.preventDefault()}
                    >
                      {o.label} {o.subLabel && <span style={{ opacity: 0.5 }}>· {o.subLabel}</span>}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <select
              className="input"
              value={draft.e_equipmentId || ""}
              onChange={(e) => {
                const id = e.target.value;
                if (id === NONE_VALUE) {
                  handleEquipSelect(NONE_VALUE, "");
                } else if (id) {
                  const found = equipOptions.find((o) => o.id === id);
                  handleEquipSelect(id, found?.label || "");
                } else {
                  handleEquipSelect("", "");
                }
              }}
              style={{ width: 120 }}
            >
              <option value="">▼ 선택</option>
              <option value={NONE_VALUE}>해당없음</option>
              {equipOptions.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.label}
                </option>
              ))}
            </select>
            <button type="button" className="btn" onClick={() => setShowEquipForm((v) => !v)}>
              {showEquipForm ? "닫기" : "추가"}
            </button>
          </div>
          {draft.e_equipmentLabel && draft.e_equipmentId !== NONE_VALUE && (
            <div style={{ fontSize: 12, opacity: 0.7 }}>선택됨: {draft.e_equipmentLabel}</div>
          )}
          {draft.e_equipmentId === NONE_VALUE && <div style={{ fontSize: 12, opacity: 0.7 }}>해당없음</div>}
        </div>
      </div>

      {/* 설비 인라인 추가 폼 */}
      {showEquipForm && (
        <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
          <div style={{ display: "grid", gap: 8 }}>
            <div>
              <div className="p" style={{ marginTop: 0 }}>
                설비명 *
              </div>
              <input
                className="input"
                value={equipDraft.name}
                onChange={(e) => setEquipDraft({ ...equipDraft, name: e.target.value })}
              />
            </div>
            <div>
              <div className="p" style={{ marginTop: 0 }}>
                설치 위치 *
              </div>
              <input
                className="input"
                value={equipDraft.location}
                onChange={(e) => setEquipDraft({ ...equipDraft, location: e.target.value })}
              />
            </div>
            <div className="row">
              <button type="button" className="btn primary" onClick={submitEquip}>
                저장
              </button>
              <button type="button" className="btn" onClick={() => setShowEquipForm(false)}>
                취소
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 심각도 */}
      <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
        <div className="p">심각도</div>
        <div className="row" style={{ marginTop: 0 }}>
          {(["낮음", "보통", "높음"] as const).map((sev) => (
            <button
              key={sev}
              type="button"
              className={`selBtn ${draft.e_severity === sev ? "active" : ""}`}
              onClick={() => onUpdate("e_severity", sev)}
            >
              {sev}
            </button>
          ))}
        </div>
      </div>

      {/* 증상 */}
      <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
        <div className="p">증상</div>
        <textarea
          className="textarea"
          rows={2}
          value={draft.e_symptom}
          onChange={(e) => onUpdate("e_symptom", e.target.value)}
        />
      </div>

      {/* 진행상태 */}
      <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
        <div className="p">진행상태</div>
        <div className="row" style={{ marginTop: 0 }}>
          {(["진행중", "완료"] as const).map((st) => (
            <button
              key={st}
              type="button"
              className={`selBtn ${draft.e_status === st ? "active" : ""}`}
              onClick={() => onUpdate("e_status", st)}
            >
              {st === "진행중" ? "진행중" : "해결완료"}
            </button>
          ))}
        </div>
      </div>

      {/* 해결완료일 때만 조치/예방 필드 표시 */}
      {draft.e_status === "완료" && (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
            <div className="p">조치</div>
            <textarea
              className="textarea"
              rows={2}
              value={draft.e_action}
              onChange={(e) => onUpdate("e_action", e.target.value)}
            />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
            <div className="p">예방</div>
            <textarea
              className="textarea"
              rows={2}
              value={draft.e_prevent}
              onChange={(e) => onUpdate("e_prevent", e.target.value)}
            />
          </div>
        </>
      )}
    </>
  );
}

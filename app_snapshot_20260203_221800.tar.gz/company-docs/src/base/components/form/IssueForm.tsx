/**
 * IssueForm - 이슈 기록 폼 컴포넌트 (범용)
 * 
 * 사용처:
 * - RegisterIssue 페이지
 * - RegisterProductionDaily 페이지 (이슈 추가 패널)
 * 
 * Props:
 * - recordDate: 기록일 (일지에서 불러올 때는 해당 일지 날짜)
 * - writerName, writerRole: 작성자 정보
 * - onSubmit: 저장 콜백
 * - onCancel: 취소 콜백
 * - embedded: 다른 페이지에 삽입된 경우 true (헤더 숨김)
 */
import { useEffect, useState } from "react";
import TagInputText from "../TagInputText";
import { ConfirmedTagChips, SuggestionItem } from "../TagWidgets";
import { useAutoTitle, useTagSuggestion, validateFields } from "../../hooks";
import { defaultIssueDraft, toIssueItem, type IssueDraft, type IssueCategory, type IssueItem } from "../../../domain/schema/daily/issue";
import IssueQualityFields from "./IssueQualityFields";
import IssueEquipmentFields from "./IssueEquipmentFields";
import IssueSafetyFields from "./IssueSafetyFields";

const categoryLabels: Record<IssueCategory, string> = {
  quality: "품질",
  equipment: "설비",
  safety: "안전",
};

export type IssueFormProps = {
  recordDate: string;
  writerName: string;
  writerRole: string;
  site?: "대구" | "성주";
  onSubmit: (item: IssueItem, draft: IssueDraft) => void;
  onCancel?: () => void;
  embedded?: boolean;  // 다른 페이지에 삽입된 경우
  initialDraft?: Partial<IssueDraft>;
};

export default function IssueForm({
  recordDate,
  writerName,
  writerRole,
  site,
  onSubmit,
  onCancel,
  embedded = false,
  initialDraft,
}: IssueFormProps) {
  const [draft, setDraft] = useState<IssueDraft>(() => ({
    ...defaultIssueDraft(),
    recordDate,
    writerName,
    site,
    ...initialDraft,
  }));

  // 카테고리 라벨
  const catLabel = categoryLabels[draft.category] || "이슈";

  // 제목 자동 생성
  const autoTitle = useAutoTitle({
    recordDate,
    writerName,
    writerRole,
    category: catLabel,
    suffix: "이슈기록",
  });

  // Draft에 제목 동기화
  useEffect(() => {
    setDraft((prev) => ({ ...prev, title: autoTitle.title }));
  }, [autoTitle.title]);

  // 태그 추천
  const tagSuggestion = useTagSuggestion({
    scope: "issue",
    tagsText: draft.tagsText || "",
    onTagsChange: (text) => setDraft((prev) => ({ ...prev, tagsText: text })),
    contentText: draft.details || "",
  });

  // 외부 props 변경 시 동기화
  useEffect(() => {
    setDraft((prev) => ({
      ...prev,
      recordDate,
      writerName,
      site,
    }));
  }, [recordDate, writerName, site]);

  // 필드 업데이트
  function updateField<K extends keyof IssueDraft>(k: K, v: IssueDraft[K]) {
    setDraft((p) => ({ ...p, [k]: v }));
  }

  // 저장
  function handleSubmit() {
    // 필수 필드 검증
    const validation = validateFields(
      {
        writerName,
        writerRole,
        title: autoTitle.title,
        details: draft.details,
      },
      [
        { name: "writerName", label: "작성자", required: true },
        { name: "writerRole", label: "직책", required: true },
        { name: "title", label: "제목", required: true },
        { name: "details", label: "상세내용", required: true },
      ]
    );

    if (!validation.ok) {
      return alert(validation.firstError);
    }

    // 연계 필드 검증: 선택하지 않으면 저장 불가 (해당없음 또는 선택 필수)
    // 설비 이슈: e_equipmentId 필수 (빈 문자열이면 에러)
    if (draft.category === "equipment") {
      if (!draft.e_equipmentId) {
        return alert("설비를 선택하거나 '해당없음'을 선택해주세요.");
      }
    }

    // 안전 이슈: s_employeeId 필수 (빈 문자열이면 에러)
    if (draft.category === "safety") {
      if (!draft.s_employeeId) {
        return alert("직원을 선택하거나 '해당없음'을 선택해주세요.");
      }
    }

    // 태그 bump
    tagSuggestion.bumpAllTags();

    // 최종 Draft 구성
    const finalDraft: IssueDraft = {
      ...draft,
      recordDate,
      writerName,
      title: autoTitle.title,
    };

    const item = toIssueItem(finalDraft);
    onSubmit(item, finalDraft);

    // 리셋
    setDraft({
      ...defaultIssueDraft(),
      recordDate,
      writerName,
      site,
    });
    autoTitle.resetTitle();
  }

  // 리셋
  function handleReset() {
    setDraft({
      ...defaultIssueDraft(),
      recordDate,
      writerName,
      site,
    });
    autoTitle.resetTitle();
    onCancel?.();
  }

  return (
    <div className={embedded ? "" : "card"}>
      <div style={{ display: "grid", gap: 8 }}>
        {/* 기록일 - embedded가 아닐 때만 표시 */}
        {!embedded && (
          <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
            <div className="p">기록일 *</div>
            <input
              className="input"
              type="date"
              value={recordDate}
              disabled
              style={{ opacity: 0.7 }}
            />
          </div>
        )}

        {/* 지부 */}
        <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
          <div className="p">지부</div>
          <div className="row" style={{ marginTop: 0 }}>
            {(["대구", "성주"] as const).map((s) => (
              <button
                key={s}
                type="button"
                className={`selBtn ${draft.site === s ? "active" : ""}`}
                onClick={() => updateField("site", draft.site === s ? undefined : s)}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* 분류 */}
        <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
          <div className="p">분류</div>
          <div className="row" style={{ marginTop: 0 }}>
            {(["quality", "equipment", "safety"] as const).map((cat) => (
              <button
                key={cat}
                type="button"
                className={`selBtn ${draft.category === cat ? "active" : ""}`}
                onClick={() => updateField("category", cat)}
              >
                {categoryLabels[cat]}
              </button>
            ))}
          </div>
        </div>

        {/* 제목 */}
        <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
          <div className="p">제목 *</div>
          <input
            className="input"
            value={autoTitle.title}
            onFocus={autoTitle.onTitleFocus}
            onChange={(e) => autoTitle.setTitle(e.target.value)}
            placeholder="클릭하면 자동완성"
          />
        </div>

        {/* 상세 */}
        <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
          <div className="p">상세 *</div>
          <textarea
            className="textarea"
            rows={3}
            value={draft.details}
            onChange={(e) => updateField("details", e.target.value)}
          />
        </div>

        {/* 추천 태그 */}
        {tagSuggestion.visibleSuggestions.length > 0 && (
          <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
            <div className="p">추천 태그</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}>
              {tagSuggestion.visibleSuggestions.map((s) => (
                <SuggestionItem
                  key={`${s.source}:${s.tag}`}
                  s={s}
                  onApply={tagSuggestion.applySuggestion}
                  onDismiss={tagSuggestion.dismissSuggestion}
                  compact
                />
              ))}
              {tagSuggestion.allSuggestions.length > 5 && (
                <button type="button" className="btn" onClick={() => tagSuggestion.setShowAll((v) => !v)}>
                  {tagSuggestion.showAll ? "접기" : `더보기(${tagSuggestion.allSuggestions.length})`}
                </button>
              )}
            </div>
          </div>
        )}

        {/* 태그 */}
        <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
          <div className="p">태그</div>
          <div>
            <ConfirmedTagChips
              tagsText={draft.tagsText}
              onRemove={tagSuggestion.removeTag}
              compact
              getTone={tagSuggestion.getTone}
            />
            <TagInputText
              value={draft.tagsText}
              onChange={(text) => updateField("tagsText", text)}
              scope="issue"
              showChips={false}
            />
          </div>
        </div>

        {/* 카테고리별 필드 */}
        {draft.category === "quality" && (
          <IssueQualityFields draft={draft} onUpdate={updateField} />
        )}

        {draft.category === "equipment" && (
          <IssueEquipmentFields draft={draft} onUpdate={updateField} />
        )}

        {draft.category === "safety" && (
          <IssueSafetyFields draft={draft} onUpdate={updateField} />
        )}

        {/* 버튼 */}
        <div className="row">
          <button type="button" className="btn primary" onClick={handleSubmit}>
            저장
          </button>
          <button type="button" className="btn" onClick={handleReset}>
            {onCancel ? "취소" : "초기화"}
          </button>
        </div>
      </div>
    </div>
  );
}

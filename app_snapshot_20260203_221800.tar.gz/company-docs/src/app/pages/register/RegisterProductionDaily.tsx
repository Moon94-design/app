import { useEffect, useMemo, useRef, useState } from "react";
import { repo } from "../../../data/repo";
import { useDraftState } from "../../../base/utils/useDraftState";
import TagInputText, { bumpPersonalTag, bumpSystemTag, listPersonalTags, listSystemTags } from "../../../base/components/TagInputText";
import { ConfirmedTagChips, usePreserveSelection } from "../../../base/components/TagWidgets";

import { addIssueItem, listIssueItems, removeIssueItem } from "../../../data/issueRepo";
import { defaultIssueDraft, normalizeIssueDraft, validateIssueDraft, toIssueItem } from "../../../domain/schema/daily/issue";
import type { IssueDraft, IssueItem } from "../../../domain/schema/daily/issue";

import type { ProductionDraft, ProductionLine, ProductionRecord, Shift, Product, Item } from "../../../domain/schema/daily/production";
import { defaultProductionDraft, normalizeProductionDraft, validateProductionDraft, toProductionRecord, newLine, makeProductionDocId } from "../../../domain/schema/daily/production";

type AddMode = "none" | "line";
const KEY_DRAFT = "draft_production_daily_schema_v2";

type EquipmentRow = {
  id: string;
  name: string;
  location: string;
  equipType: string;
  equipTypeNote: string;
  importance: string;
  makerModel: string;
  installedAt: string;
  inspectCycle: string;
  inspectNote: string;
  consumableIds: string[];
  createdAt: string;
  updatedAt: string;
};

type EmployeeRow = {
  id: string;
  name: string;
  branch: "대구" | "성주";
  phone: string;
  job: string;
  memo: string;
  createdAt: string;
  updatedAt: string;
};

function newId(prefix: string) {
  // @ts-ignore
  return (globalThis.crypto?.randomUUID?.() as string) || `${prefix}_${Date.now()}_${Math.floor(Math.random() * 1e6)}`;
}

function buildAutoTitle(recordDate: string, writerName: string, writerRole: string) {
  const d = (recordDate || "").trim();
  const n = (writerName || "").trim();
  const r = (writerRole || "").trim();
  const mid = [n, r].filter(Boolean).join(" ");
  return `${d} ${mid ? mid + " " : ""}생산일지`.trim();
}

// 내용 끝 토큰(입력 중) 추출: 3글자 이상일 때 추천
function lastToken(text: string) {
  const t = (text || "").replace(/\s+/g, " ");
  const m = t.match(/([0-9A-Za-z가-힣-]{3,})\s*$/);
  return m ? m[1] : "";
}

function normLoose(s: string) {
  return (s || "").toLowerCase().replace(/[\s-]/g, "").trim();
}

type Sug = { tag: string; source: "system" | "personal" };

function buildSuggestions(details: string, selected: Set<string>, candidates: Sug[], dismissed: Set<string>) {
const token = lastToken(details) || ""; // ✅ 기존 lastToken 사용 (TS6133 제거)
  if (!token || token.length < 2) return [];

  // ✅ 2글자 미만이면 추천 유지하지 않음
  if (!token || token.length < 2) return [];

  const tokenLower = token.toLowerCase();
  const tokenLoose = normLoose(token);

  // ✅ fallback: 현재 토큰에서 매칭이 없으면 prefix 길이를 줄여가며 "마지막으로 매칭된" 후보를 유지
  let query = tokenLower;
  let queryLoose = tokenLoose;

  const matchesPrefix = (q: string, qLoose: string) => {
    const out: Sug[] = [];
    for (const c of candidates) {
      const tag = (c.tag || "").trim();
      if (!tag) continue;
      if (selected.has(tag)) continue;
      if (dismissed.has(tag)) continue;

      const a = tag.toLowerCase();
      const aLoose = normLoose(tag);

      // prefix 우선 + loose prefix(하이픈/공백 제거) 보조
      const ok = a.startsWith(q) || (qLoose && aLoose.startsWith(qLoose));
      if (!ok) continue;

      out.push(c);
      if (out.length >= 30) break; // 더보기 상한
    }
    return out;
  };

  // 1) 토큰 전체로 먼저 시도
  let out = matchesPrefix(query, queryLoose);

  // 2) 없으면 prefix를 1글자씩 줄이며(최소 2) fallback
  if (out.length === 0) {
    for (let L = tokenLower.length - 1; L >= 2; L--) {
      query = tokenLower.slice(0, L);
      queryLoose = tokenLoose.slice(0, L);
      out = matchesPrefix(query, queryLoose);
      if (out.length > 0) break;
    }
  }

  return out;
}
export default function RegisterProductionDaily() {
  const [docs, setDocs] = useState<ProductionRecord[]>(() => repo.productionDaily<ProductionRecord>().getAll());

  const { state: raw, setState: setRaw, reset, clear } = useDraftState<any>(KEY_DRAFT, defaultProductionDraft());
  const draft: ProductionDraft = useMemo(() => normalizeProductionDraft(raw), [raw]);

  const [addMode, setAddMode] = useState<AddMode>("none");
  const [line, setLine] = useState<ProductionLine>(() => newLine());
  const [baseTick, setBaseTick] = useState(0);

  // [ANCHOR:TITLE_AUTO_START]
  const [titleAuto, setTitleAuto] = useState(false);
  const titleTouchedRef = useRef(false);
  const detailsRef = useRef<HTMLTextAreaElement | null>(null);
  const preserve = usePreserveSelection(detailsRef);

  function persist(next: ProductionDraft) {
    setRaw(normalizeProductionDraft(next));
  }

  

  function ensureTitleIfAuto(nextDraft: ProductionDraft) {
    if (!titleAuto) return;
    const auto = buildAutoTitle(nextDraft.recordDate, nextDraft.writerName, nextDraft.writerRole);
    if ((nextDraft.title || "").trim() !== auto) {
      setRaw(normalizeProductionDraft({ ...nextDraft, title: auto }));
    }
  }

  function onFocusTitle() {
    titleTouchedRef.current = true;
    setTitleAuto(true);
    const auto = buildAutoTitle(draft.recordDate, draft.writerName, draft.writerRole);
    if (!(draft.title || "").trim()) {
      persist({ ...draft, title: auto });
    } else {
      ensureTitleIfAuto(draft);
    }
  }

  function onChangeTitle(v: string) {
    if (titleTouchedRef.current) setTitleAuto(false);
    persist({ ...draft, title: v });
  }
  // [ANCHOR:TITLE_AUTO_END]

  function toggle(m: AddMode) {
    setAddMode((p) => (p === m ? "none" : m));
  }

  // 기준정보 후보(확장): 모든 기준등록 명칭 + (태그 인덱스 system/personal)
  const candidatePool: Sug[] = useMemo(() => {
    const agencies = repo.agencies<any>().getAll().map((x: any) => (x?.name || x?.baseName || "").trim()).filter(Boolean);
    const partners = repo.partners<any>().getAll().map((x: any) => (x?.name || "").trim()).filter(Boolean);
    const vehicles = repo.vehicles<any>().getAll().map((x: any) => (x?.vehicleNo || "").trim()).filter(Boolean);
    const equipments = repo.equipments<any>().getAll().map((x: any) => (x?.name || "").trim()).filter(Boolean);
    const employees = repo.employees<any>().getAll().map((x: any) => (x?.name || "").trim()).filter(Boolean);
    const vendors = repo.vendors<any>().getAll().map((x: any) => (x?.name || "").trim()).filter(Boolean);
    const consumables = repo.consumables<any>().getAll().map((x: any) => (x?.name || "").trim()).filter(Boolean);

    const systemTags = listSystemTags().filter((t) => t.trim().length >= 2);
    const personalTags = listPersonalTags().filter((t) => t.trim().length >= 2);

    const seen = new Set<string>();
    const out: Sug[] = [];

    const push = (tag: string, source: "system" | "personal") => {
      const t = (tag || "").trim();
      if (!t) return;
      if (seen.has(`${source}:${t}`)) return;
      // 동일 태그는 source 우선순위: personal 먼저 넣고, system은 같은 태그면 생략
      if (source === "system" && personalTags.includes(t)) return;
      seen.add(`${source}:${t}`);
      out.push({ tag: t, source });
    };

    // personal tags 먼저
    for (const t of personalTags) push(t, "personal");
    // system tags
    for (const t of systemTags) push(t, "system");

    // 기준정보 이름은 system 취급
    for (const t of agencies) push(t, "system");
    for (const t of partners) push(t, "system");
    for (const t of vehicles) push(t, "system");
    for (const t of equipments) push(t, "system");
    for (const t of employees) push(t, "system");
    for (const t of vendors) push(t, "system");
    for (const t of consumables) push(t, "system");

    return out.slice(0, 600);
  }, [baseTick]);

  const selectedTags = useMemo(() => {
    const set = new Set<string>();
    (draft.tagsText || "")
      .split(",")
      .map((x) => x.trim())
      .filter(Boolean)
      .forEach((t) => set.add(t.startsWith("#") ? t.slice(1).trim() : t));
    return set;
  }, [draft.tagsText]);

  // [ANCHOR:TAG_SUGGEST_START]
const [dismissed, setDismissed] = useState<Set<string>>(() => new Set());
const [showAll, setShowAll] = useState(false);

// ✅ 현재 타이핑 중 토큰(마지막 토큰). 추천은 2글자부터만 표시
const currentToken = useMemo(() => {
  const t = draft.details || "";
  const m = t.match(/([0-9A-Za-z가-힣-]{1,})$/);
  return m ? m[1] : "";
}, [draft.details]);

// ✅ 글을 "지우면"(길이 감소) dismissed 초기화 + 더보기 접기
const prevLenRef = useRef<number>((draft.details || "").length);
useEffect(() => {
  const len = (draft.details || "").length;
  if (len < prevLenRef.current) {
    setDismissed(new Set());
    setShowAll(false);
  }
  prevLenRef.current = len;
}, [draft.details]);

function normalizeLoose(s: string) {
  return normLoose((s || "").trim());
}

// ---------------------------------------
// ✅ typing 추천(관대): 2글자부터
// - prefix/contains/suffix 허용
// - 3-gram 윈도우(느슨한) 보조
// - 정렬: 점수(매칭 강도) → 태그 길이(긴 것 우선)
// - 짧은 포함 태그도 "후순위로 남김"
// ---------------------------------------
function typingSuggestions(tokenRaw: string): Sug[] {
  const token = (tokenRaw || "").trim();
  if (token.length < 2) return [];

  const q = token.toLowerCase();
  const qLoose = normalizeLoose(token);

  const grams3: string[] = [];
  if (qLoose.length >= 3) {
    for (let i = 0; i <= qLoose.length - 3; i++) grams3.push(qLoose.slice(i, i + 3));
  }

  const scored: Array<{ s: Sug; score: number; len: number }> = [];

  for (const c of candidatePool) {
    const tag = (c.tag || "").trim();
    if (!tag) continue;
    if (selectedTags.has(tag)) continue;
    if (dismissed.has(tag)) continue;

    const a = tag.toLowerCase();
    const aLoose = normalizeLoose(tag);

    let score = 0;

    // 강한 매칭: prefix
    if (a.startsWith(q) || (qLoose && aLoose.startsWith(qLoose))) score += 40;

    // 중간 포함
    if (a.includes(q) || (qLoose && aLoose.includes(qLoose))) score += 20;

    // 끝 포함(suffix): "끝글자 쳤을 때"도 잡힘
    if (a.endsWith(q) || (qLoose && aLoose.endsWith(qLoose))) score += 25;

    // 3-gram 윈도우 보조(타이핑 중 관대)
    if (score === 0 && grams3.length) {
      const hit3 = grams3.some((g) => aLoose.includes(g));
      if (hit3) score += 10;
    }

    if (score === 0) continue;

    scored.push({ s: c, score, len: tag.length });
  }

  scored.sort((x, y) => y.score - x.score || y.len - x.len);
  return scored.slice(0, 30).map((x) => x.s);
}

// ✅ 추천 리스트
const allSug = useMemo(() => typingSuggestions(currentToken), [
  currentToken,
  candidatePool,
  selectedTags,
  dismissed,
]);

// ✅ buildSuggestions 미사용(TS6133) 방지용: legacy 계산 (UI에는 안 씀)
const _legacySug = useMemo(
  () => buildSuggestions(currentToken, selectedTags, candidatePool, dismissed),
  [currentToken, selectedTags, candidatePool, dismissed]
);
void _legacySug;

const visibleSug = useMemo(() => {
  if (showAll) return allSug;
  return allSug.slice(0, 5);
}, [allSug, showAll]);

// ---------------------------------------
// ✅ 단어 경계에서 "완성 명칭 포함" 태그를 확정 추가
// - 공백/엔터/구두점 입력 시점에만 커밋(연산 최소)
// - 포함 기준: token.includes(tag) (연속 포함)
// - 겹치면 "가장 긴 태그만" 확정(longest-wins)
// ---------------------------------------
const lastCommittedRef = useRef<string>("");

function pickCommittedTagsFromToken(tokenRaw: string): string[] {
  const token = (tokenRaw || "").trim();
  if (!token) return [];

  const tokenLower = token.toLowerCase();
  const tokenLoose = normalizeLoose(token);

  const hits: string[] = [];
  for (const c of candidatePool) {
    const tag = (c.tag || "").trim();
    if (!tag) continue;
    if (selectedTags.has(tag)) continue;

    const tagLower = tag.toLowerCase();
    const tagLoose = normalizeLoose(tag);

    const ok =
      tokenLower.includes(tagLower) ||
      (tagLoose && tokenLoose.includes(tagLoose));

    if (ok) hits.push(tag);
  }

  // longest-wins: 긴 태그가 있으면 그 내부의 짧은 태그는 탈락
  hits.sort((a, b) => b.length - a.length);
  const kept: string[] = [];
  for (const t of hits) {
    const tl = t.toLowerCase();
    const shadowed = kept.some((k) => k.toLowerCase().includes(tl));
    if (!shadowed) kept.push(t);
  }
  return kept;
}

function commitTags(tags: string[]) {
  if (!tags.length) return;
  preserve(() => {
    const next = (draft.tagsText || "").trim();
    const existing = new Set(
      next ? next.split(",").map((x) => x.trim()).filter(Boolean) : []
    );

    let changed = false;
    for (const t of tags) {
      if (!existing.has(t)) {
        existing.add(t);
        changed = true;
      }
    }
    if (!changed) return;

    const merged = Array.from(existing).join(", ");
    persist({ ...draft, tagsText: merged });
  });
}

useEffect(() => {
  const d = draft.details || "";
  if (!d) return;

  const lastChar = d.slice(-1);
  const isBoundary = /[\s\n\r\t.,!?;:(){}\[\]"'“”‘’]/.test(lastChar);
  if (!isBoundary) return;

  // 경계 직전 토큰(1글자도 허용: a 태그 같은 것도 커밋 가능)
  const trimmed = d.replace(/[\s\n\r\t.,!?;:(){}\[\]"'“”‘’]+$/, "");
  const m = trimmed.match(/([0-9A-Za-z가-힣-]{1,})$/);
  const token = m ? m[1] : "";
  if (!token) return;

  // 같은 토큰 연속 커밋 방지
  if (lastCommittedRef.current === token) return;
  lastCommittedRef.current = token;

  const tags = pickCommittedTagsFromToken(token);
  commitTags(tags);
}, [draft.details, candidatePool, selectedTags]);

// ---------------------------------------
// ✅ 추천 클릭/삭제
// ---------------------------------------
function applySuggested(s: Sug) {
  const t = (s.tag || "").trim();
  if (!t) return;
  if (selectedTags.has(t)) return;
  preserve(() => {
    if (s.source === "system") bumpSystemTag("production", t);
    else bumpPersonalTag("production", t);

    const next = (draft.tagsText || "").trim();
    const merged = next ? `${next}, ${t}` : t;
    persist({ ...draft, tagsText: merged });
  });
}

function dismissSuggested(tag: string) {
  const t = (tag || "").trim();
  if (!t) return;
  preserve(() => setDismissed((prev) => {
    const n = new Set(prev);
    n.add(t);
    return n;
  }));
}
// [ANCHOR:TAG_SUGGEST_END]

  function addLine() {
    const l: ProductionLine = {
      ...line,
      bags: Number(line.bags) || 0,
      kg: Number(line.kg) || 0,
      memo: (line.memo || "").trim(),
    };
    persist({ ...draft, lines: [l, ...(draft.lines || [])] });
    setLine(newLine());
  }

  function removeLine(id: string) {
    persist({ ...draft, lines: (draft.lines || []).filter((x) => x.id !== id) });
  }

  // 자동모드면 날짜/작성자/직책 변화에 따라 제목 갱신
  useEffect(() => {
    if (!titleAuto) return;
    ensureTitleIfAuto(draft);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [draft.recordDate, draft.writerName, draft.writerRole, titleAuto]);

  function upsertSave() {
    const vr = validateProductionDraft(draft);
    if (!vr.ok) return alert(vr.errors[0]?.message || "입력값을 확인하세요.");

    const stableId = makeProductionDocId(draft.recordDate, draft.site, draft.writerName);
    const now = new Date().toISOString();

    const finalDraft = (() => {
      const t = (draft.title || "").trim();
      if (t) return draft;
      return { ...draft, title: buildAutoTitle(draft.recordDate, draft.writerName, draft.writerRole) };
    })();

    const nextDoc: ProductionRecord = {
      ...toProductionRecord(finalDraft, stableId),
      createdAt: (() => {
        const prev = docs.find((d) => d.id === stableId);
        return prev?.createdAt || now;
      })(),
      updatedAt: now,
    };

    const next = [nextDoc, ...docs.filter((d) => d.id !== stableId)];
    setDocs(next);
    repo.productionDaily<ProductionRecord>().setAll(next);

    alert("저장되었습니다.");
  }

  function removeDoc(id: string) {
    const next = docs.filter((d) => d.id !== id);
    setDocs(next);
    repo.productionDaily<ProductionRecord>().setAll(next);
  }

  // --- Issue panel component (inline) ---
  function IssuePanel() {
    const noneOption = "__none__";
    const [items, setItems] = useState<IssueItem[]>(() => listIssueItems(draft.recordDate, draft.writerName));
    const [open, setOpen] = useState(false);
    const [issueDraft, setIssueDraft] = useState<IssueDraft>(() => ({
      ...defaultIssueDraft(),
      recordDate: draft.recordDate,
      writerName: draft.writerName,
      site: draft.site,
    }));

    const [equipments, setEquipments] = useState<EquipmentRow[]>(() => repo.equipments<EquipmentRow>().getAll());
    const [employees, setEmployees] = useState<EmployeeRow[]>(() => repo.employees<EmployeeRow>().getAll());

    const [showEquipForm, setShowEquipForm] = useState(false);
    const [equipDraft, setEquipDraft] = useState({
      name: "",
      location: "",
      equipType: "생산설비",
      equipTypeNote: "",
      importance: "중",
      makerModel: "",
      installedAt: "",
      inspectCycle: "월간",
      inspectNote: "",
    });
    const [equipEditId, setEquipEditId] = useState<string>("");
    const [equipDupId, setEquipDupId] = useState<string>("");

    const [showEmpForm, setShowEmpForm] = useState(false);
    const [empDraft, setEmpDraft] = useState({ name: "", branch: "대구" as "대구" | "성주", phone: "", job: "", memo: "" });
    const [empEditId, setEmpEditId] = useState<string>("");
    const [empDupId, setEmpDupId] = useState<string>("");

    useEffect(() => {
      setItems(listIssueItems(draft.recordDate, draft.writerName));
    }, [draft.recordDate, draft.writerName]);

    useEffect(() => {
      setIssueDraft((prev) => normalizeIssueDraft({
        ...prev,
        recordDate: draft.recordDate,
        writerName: draft.writerName,
        site: draft.site,
      }));
    }, [draft.recordDate, draft.writerName, draft.site]);

    const seededRef = useRef<Set<string>>(new Set());

    useEffect(() => {
      if (!open) return;
      const nextEquip = repo.equipments<EquipmentRow>().getAll();
      const nextEmp = repo.employees<EmployeeRow>().getAll();
      setEquipments(nextEquip);
      setEmployees(nextEmp);

      const agencies = repo.agencies<any>().getAll().map((x: any) => (x?.name || x?.baseName || "").trim()).filter(Boolean);
      const partners = repo.partners<any>().getAll().map((x: any) => (x?.name || "").trim()).filter(Boolean);
      const vehicles = repo.vehicles<any>().getAll().map((x: any) => (x?.vehicleNo || "").trim()).filter(Boolean);
      const vendors = repo.vendors<any>().getAll().map((x: any) => (x?.name || "").trim()).filter(Boolean);
      const consumables = repo.consumables<any>().getAll().map((x: any) => (x?.name || "").trim()).filter(Boolean);

      const seed = seededRef.current;
      const push = (t: string) => {
        const tag = (t || "").trim();
        if (!tag) return;
        if (seed.has(tag)) return;
        seed.add(tag);
        bumpSystemTag("issue", tag);
      };

      nextEquip.forEach((e) => push(e.name));
      nextEmp.forEach((e) => push(e.name));
      agencies.forEach(push);
      partners.forEach(push);
      vehicles.forEach(push);
      vendors.forEach(push);
      consumables.forEach(push);
    }, [open]);

    // 이슈 상세 기반 추천 로직 (생산일지와 동일 규칙)
    const [issueDismissed, setIssueDismissed] = useState<Set<string>>(() => new Set());
    const [issueShowAll, setIssueShowAll] = useState(false);

    const issueSelectedTags = useMemo(() => {
      const set = new Set<string>();
      (issueDraft.tagsText || "")
        .split(",")
        .map((x) => x.trim())
        .filter(Boolean)
        .forEach((t) => set.add(t.startsWith("#") ? t.slice(1).trim() : t));
      return set;
    }, [issueDraft.tagsText]);

    const issueCurrentToken = useMemo(() => {
      const t = issueDraft.details || "";
      const m = t.match(/([0-9A-Za-z가-힣-]{1,})$/);
      return m ? m[1] : "";
    }, [issueDraft.details]);

    const issuePrevLenRef = useRef<number>((issueDraft.details || "").length);
    useEffect(() => {
      const len = (issueDraft.details || "").length;
      if (len < issuePrevLenRef.current) {
        setIssueDismissed(new Set());
        setIssueShowAll(false);
      }
      issuePrevLenRef.current = len;
    }, [issueDraft.details]);

    function issueNormalizeLoose(s: string) {
      return normLoose((s || "").trim());
    }

    function issueTypingSuggestions(tokenRaw: string): Sug[] {
      const token = (tokenRaw || "").trim();
      if (token.length < 2) return [];

      const q = token.toLowerCase();
      const qLoose = issueNormalizeLoose(token);

      const grams3: string[] = [];
      if (qLoose.length >= 3) {
        for (let i = 0; i <= qLoose.length - 3; i++) grams3.push(qLoose.slice(i, i + 3));
      }

      const scored: Array<{ s: Sug; score: number; len: number }> = [];

      for (const c of candidatePool) {
        const tag = (c.tag || "").trim();
        if (!tag) continue;
        if (issueSelectedTags.has(tag)) continue;
        if (issueDismissed.has(tag)) continue;

        const a = tag.toLowerCase();
        const aLoose = issueNormalizeLoose(tag);

        let score = 0;

        if (a.startsWith(q) || (qLoose && aLoose.startsWith(qLoose))) score += 40;
        if (a.includes(q) || (qLoose && aLoose.includes(qLoose))) score += 20;
        if (a.endsWith(q) || (qLoose && aLoose.endsWith(qLoose))) score += 25;

        if (score === 0 && grams3.length) {
          const hit3 = grams3.some((g) => aLoose.includes(g));
          if (hit3) score += 10;
        }

        if (score === 0) continue;

        scored.push({ s: c, score, len: tag.length });
      }

      scored.sort((x, y) => y.score - x.score || y.len - x.len);
      return scored.slice(0, 30).map((x) => x.s);
    }

    const issueAllSug = useMemo(() => issueTypingSuggestions(issueCurrentToken), [
      issueCurrentToken,
      candidatePool,
      issueSelectedTags,
      issueDismissed,
    ]);

    const issueVisibleSug = useMemo(() => {
      if (issueShowAll) return issueAllSug;
      return issueAllSug.slice(0, 5);
    }, [issueAllSug, issueShowAll]);

    const issueLastCommittedRef = useRef<string>("");

    function issuePickCommittedTagsFromToken(tokenRaw: string): string[] {
      const token = (tokenRaw || "").trim();
      if (!token) return [];

      const tokenLower = token.toLowerCase();
      const tokenLoose = issueNormalizeLoose(token);

      const hits: string[] = [];
      for (const c of candidatePool) {
        const tag = (c.tag || "").trim();
        if (!tag) continue;
        if (issueSelectedTags.has(tag)) continue;

        const tagLower = tag.toLowerCase();
        const tagLoose = issueNormalizeLoose(tag);

        const ok =
          tokenLower.includes(tagLower) ||
          (tagLoose && tokenLoose.includes(tagLoose));

        if (ok) hits.push(tag);
      }

      hits.sort((a, b) => b.length - a.length);
      const kept: string[] = [];
      for (const t of hits) {
        const tl = t.toLowerCase();
        const shadowed = kept.some((k) => k.toLowerCase().includes(tl));
        if (!shadowed) kept.push(t);
      }
      return kept;
    }

    function issueCommitTags(tags: string[]) {
      if (!tags.length) return;
      const next = (issueDraft.tagsText || "").trim();
      const existing = new Set(
        next ? next.split(",").map((x) => x.trim()).filter(Boolean) : []
      );

      let changed = false;
      for (const t of tags) {
        if (!existing.has(t)) {
          existing.add(t);
          changed = true;
        }
      }
      if (!changed) return;

      const merged = Array.from(existing).join(", ");
      updateField("tagsText", merged as any);
    }

    useEffect(() => {
      const d = issueDraft.details || "";
      if (!d) return;

      const lastChar = d.slice(-1);
      const isBoundary = /[\s\n\r\t.,!?;:(){}\[\]"'“”‘’]/.test(lastChar);
      if (!isBoundary) return;

      const trimmed = d.replace(/[\s\n\r\t.,!?;:(){}\[\]"'“”‘’]+$/, "");
      const m = trimmed.match(/([0-9A-Za-z가-힣-]{1,})$/);
      const token = m ? m[1] : "";
      if (!token) return;

      if (issueLastCommittedRef.current === token) return;
      issueLastCommittedRef.current = token;

      const tags = issuePickCommittedTagsFromToken(token);
      issueCommitTags(tags);
    }, [issueDraft.details, candidatePool, issueSelectedTags]);

    function applyIssueSuggested(s: Sug) {
      const t = (s.tag || "").trim();
      if (!t) return;
      if (issueSelectedTags.has(t)) return;
      if (s.source === "system") bumpSystemTag("issue", t);
      else bumpPersonalTag("issue", t);

      const next = (issueDraft.tagsText || "").trim();
      const merged = next ? `${next}, ${t}` : t;
      updateField("tagsText", merged as any);
    }

    function dismissIssueSuggested(tag: string) {
      const t = (tag || "").trim();
      if (!t) return;
      setIssueDismissed((prev) => {
        const n = new Set(prev);
        n.add(t);
        return n;
      });
    }

    function updateField<K extends keyof IssueDraft>(k: K, v: IssueDraft[K]) {
      setIssueDraft((p) => ({ ...p, [k]: v }));
    }

    function submitIssue() {
      const vr = validateIssueDraft(issueDraft);
      if (!vr.ok) return alert(vr.errors[0]?.message || "입력값을 확인하세요.");

      const tags = (issueDraft.tagsText || "")
        .split(",")
        .map((x) => (x || "").trim())
        .filter(Boolean)
        .map((x) => (x.startsWith("#") ? x.slice(1).trim() : x));

      for (const t of tags) {
        const isSystem = candidatePool.some((c) => c.tag === t && c.source === "system");
        if (isSystem) bumpSystemTag("issue", t);
        else bumpPersonalTag("issue", t);
      }

      const item = toIssueItem(issueDraft);
      addIssueItem(issueDraft.recordDate, issueDraft.writerName, item);
      setItems(listIssueItems(issueDraft.recordDate, issueDraft.writerName));
      setOpen(false);
      setIssueDraft(defaultIssueDraft());
      alert("이슈가 저장되었습니다.");
    }

    function doRemove(id: string) {
      removeIssueItem(draft.recordDate, draft.writerName, id);
      setItems(listIssueItems(draft.recordDate, draft.writerName));
    }

    function resetEquipDraft() {
      setEquipDraft({
        name: "",
        location: "",
        equipType: "생산설비",
        equipTypeNote: "",
        importance: "중",
        makerModel: "",
        installedAt: "",
        inspectCycle: "월간",
        inspectNote: "",
      });
      setEquipEditId("");
      setEquipDupId("");
    }

    function submitEquip() {
      const name = (equipDraft.name || "").trim();
      const location = (equipDraft.location || "").trim();
      if (!name) return alert("설비명을 입력하세요.");
      if (!location) return alert("설치 위치/구역을 입력하세요.");

      const dupes = equipments.filter((e) => (e.name || "").trim() === name && e.id !== equipEditId);
      if (dupes.length && !equipEditId) {
        setEquipDupId(dupes[0].id);
        return alert("동일한 설비명이 이미 존재합니다. 드롭다운에서 수정하거나 기존 항목을 사용하세요.");
      }

      const now = new Date().toISOString();
      if (equipEditId) {
        const next = equipments.map((e) => (
          e.id === equipEditId
            ? {
                ...e,
                name,
                location,
                equipType: equipDraft.equipType,
                equipTypeNote: equipDraft.equipTypeNote.trim(),
                importance: equipDraft.importance,
                makerModel: equipDraft.makerModel.trim(),
                installedAt: equipDraft.installedAt.trim(),
                inspectCycle: equipDraft.inspectCycle,
                inspectNote: equipDraft.inspectNote.trim(),
                updatedAt: now,
              }
            : e
        ));
        setEquipments(next);
        repo.equipments<EquipmentRow>().setAll(next);
        resetEquipDraft();
        setShowEquipForm(false);
        setBaseTick((t) => t + 1);
        return alert("설비가 수정되었습니다.");
      }

      const row: EquipmentRow = {
        id: newId("EQ"),
        name,
        location,
        equipType: equipDraft.equipType,
        equipTypeNote: equipDraft.equipTypeNote.trim(),
        importance: equipDraft.importance,
        makerModel: equipDraft.makerModel.trim(),
        installedAt: equipDraft.installedAt.trim(),
        inspectCycle: equipDraft.inspectCycle,
        inspectNote: equipDraft.inspectNote.trim(),
        consumableIds: [],
        createdAt: now,
        updatedAt: now,
      };

      const next = [row, ...equipments];
      setEquipments(next);
      repo.equipments<EquipmentRow>().setAll(next);
      resetEquipDraft();
      setShowEquipForm(false);
      setBaseTick((t) => t + 1);
      alert("설비가 추가되었습니다.");
    }

    function loadEquipToEdit(id: string) {
      const found = equipments.find((e) => e.id === id);
      if (!found) return;
      setEquipEditId(found.id);
      setEquipDraft({
        name: found.name || "",
        location: found.location || "",
        equipType: found.equipType || "생산설비",
        equipTypeNote: found.equipTypeNote || "",
        importance: found.importance || "중",
        makerModel: found.makerModel || "",
        installedAt: found.installedAt || "",
        inspectCycle: found.inspectCycle || "월간",
        inspectNote: found.inspectNote || "",
      });
      setShowEquipForm(true);
    }

    function resetEmpDraft() {
      setEmpDraft({ name: "", branch: "대구", phone: "", job: "", memo: "" });
      setEmpEditId("");
      setEmpDupId("");
    }

    function submitEmp() {
      const name = (empDraft.name || "").trim();
      if (!name) return alert("이름을 입력하세요.");
      if (!empDraft.phone.trim()) return alert("연락처를 입력하세요.");
      if (!empDraft.job.trim()) return alert("직무를 입력하세요.");

      const dupes = employees.filter((e) => (e.name || "").trim() === name && e.id !== empEditId);
      if (dupes.length && !empEditId) {
        setEmpDupId(dupes[0].id);
        return alert("동일한 직원명이 이미 존재합니다. 드롭다운에서 수정하거나 기존 항목을 사용하세요.");
      }

      const now = new Date().toISOString();
      if (empEditId) {
        const next = employees.map((e) => (
          e.id === empEditId
            ? { ...e, name, branch: empDraft.branch, phone: empDraft.phone.trim(), job: empDraft.job.trim(), memo: empDraft.memo.trim(), updatedAt: now }
            : e
        ));
        setEmployees(next);
        repo.employees<EmployeeRow>().setAll(next);
        resetEmpDraft();
        setShowEmpForm(false);
        setBaseTick((t) => t + 1);
        return alert("직원이 수정되었습니다.");
      }

      const row: EmployeeRow = {
        id: newId("EMP"),
        name,
        branch: empDraft.branch,
        phone: empDraft.phone.trim(),
        job: empDraft.job.trim(),
        memo: empDraft.memo.trim(),
        createdAt: now,
        updatedAt: now,
      };

      const next = [row, ...employees];
      setEmployees(next);
      repo.employees<EmployeeRow>().setAll(next);
      resetEmpDraft();
      setShowEmpForm(false);
      setBaseTick((t) => t + 1);
      alert("직원이 추가되었습니다.");
    }

    function loadEmpToEdit(id: string) {
      const found = employees.find((e) => e.id === id);
      if (!found) return;
      setEmpEditId(found.id);
      setEmpDraft({ name: found.name || "", branch: found.branch || "대구", phone: found.phone || "", job: found.job || "", memo: found.memo || "" });
      setShowEmpForm(true);
    }

    return (
      <div>
        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
          <div className="p" style={{ margin: 0, opacity: 0.9 }}>{items.length}개</div>
          <button type="button" className="btn" onClick={() => setOpen((v) => !v)}>{open ? "취소" : "이슈 추가"}</button>
        </div>

        {open ? (
          <div className="card" style={{ marginTop: 8, background: "rgba(255,255,255,0.02)" }}>
            <div style={{ display: "grid", gap: 8 }}>
              <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
                <div className="p">기록일</div>
                <input className="input" value={issueDraft.recordDate} disabled />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
                <div className="p">지부</div>
                <select className="input" value={issueDraft.site || ""} onChange={(e) => updateField("site", e.target.value as any)}>
                  <option value="">선택</option>
                  <option value="대구">대구</option>
                  <option value="성주">성주</option>
                </select>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
                <div className="p">분류</div>
                <select className="input" value={issueDraft.category} onChange={(e) => updateField("category", e.target.value as any)}>
                  <option value="quality">품질</option>
                  <option value="equipment">설비</option>
                  <option value="safety">안전</option>
                </select>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
                <div className="p">제목</div>
                <input className="input" value={issueDraft.title} onChange={(e) => updateField("title", e.target.value)} />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
                <div className="p">상세</div>
                <textarea className="textarea" rows={3} value={issueDraft.details} onChange={(e) => updateField("details", e.target.value)} />
              </div>

              {/* 추천 태그(이슈 상세 입력 기준) */}
              {issueVisibleSug.length ? (
                <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
                  <div className="p">추천 태그</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}>
                    {issueVisibleSug.map((s) => {
                      const isSystem = s.source === "system";
                      return (
                        <div
                          key={`issue:${s.source}:${s.tag}`}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            borderRadius: 999,
                            overflow: "hidden",
                            border: isSystem ? "1px solid rgba(70,130,255,0.65)" : "1px solid rgba(255,255,255,0.10)",
                            background: isSystem ? "rgba(70,130,255,0.20)" : "rgba(255,255,255,0.06)",
                          }}
                        >
                          <button
                            type="button"
                            className="btn"
                            style={{
                              borderRadius: 0,
                              background: "transparent",
                              padding: "8px 10px",
                              flex: 3,
                              textAlign: "left",
                            }}
                            onClick={() => applyIssueSuggested(s)}
                          >
                            #{s.tag}
                          </button>

                          <button
                            type="button"
                            className="btn"
                            style={{
                              borderRadius: 0,
                              background: "rgba(255,70,70,0.18)",
                              borderLeft: "1px solid rgba(255,70,70,0.25)",
                              padding: "8px 10px",
                              flex: 1,
                              minWidth: 46,
                            }}
                            title="추천에서 제외"
                            onClick={() => dismissIssueSuggested(s.tag)}
                          >
                            🗑
                          </button>
                        </div>
                      );
                    })}

                    {issueAllSug.length > 5 ? (
                      <button type="button" className="btn" onClick={() => setIssueShowAll((v) => !v)}>
                        {issueShowAll ? "접기" : `더보기(${issueAllSug.length})`}
                      </button>
                    ) : null}
                  </div>
                </div>
              ) : null}

              <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
                <div className="p">태그</div>
                <div>
                  <ConfirmedTagChips
                    tagsText={issueDraft.tagsText}
                    onRemove={(t) => {
                      const arr = (issueDraft.tagsText || "")
                        .split(",")
                        .map((y) => y.trim())
                        .filter(Boolean)
                        .filter((y) => y !== t);
                      updateField("tagsText", arr.join(", ") as any);
                    }}
                    compact={true}
                  />
                  <TagInputText value={issueDraft.tagsText} onChange={(next) => updateField("tagsText", next)} scope="issue" showChips={false} />
                </div>
              </div>

              {/* category specific */}
              {issueDraft.category === "quality" ? (
                <>
                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
                    <div className="p">종류</div>
                    <select className="input" value={issueDraft.q_kind || ""} onChange={(e) => updateField("q_kind", e.target.value as any)}>
                      <option value="">선택</option>
                      <option value="압축품">압축품</option>
                      <option value="분쇄품">분쇄품</option>
                      <option value="펠렛">펠렛</option>
                    </select>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
                    <div className="p">품목</div>
                    <select className="input" value={issueDraft.q_item || ""} onChange={(e) => updateField("q_item", e.target.value as any)}>
                      <option value="">선택</option>
                      <option value="PP">PP</option>
                      <option value="PE">PE</option>
                    </select>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
                    <div className="p">심각도</div>
                    <select className="input" value={issueDraft.q_severity} onChange={(e) => updateField("q_severity", e.target.value as any)}>
                      <option value="낮음">낮음</option>
                      <option value="보통">보통</option>
                      <option value="높음">높음</option>
                    </select>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
                    <div className="p">원인</div>
                    <textarea className="textarea" rows={2} value={issueDraft.q_cause} onChange={(e) => updateField("q_cause", e.target.value)} />
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
                    <div className="p">조치</div>
                    <textarea className="textarea" rows={2} value={issueDraft.q_action} onChange={(e) => updateField("q_action", e.target.value)} />
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
                    <div className="p">재발방지</div>
                    <textarea className="textarea" rows={2} value={issueDraft.q_prevent} onChange={(e) => updateField("q_prevent", e.target.value)} />
                  </div>
                </>
              ) : null}

              {issueDraft.category === "equipment" ? (
                <>
                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
                    <div className="p">설비</div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 8, alignItems: "center" }}>
                      <select
                        className="input"
                        value={issueDraft.e_equipmentId || ""}
                        onChange={(e) => {
                          const id = e.target.value;
                          if (id === noneOption) {
                            updateField("e_equipmentId", noneOption);
                            updateField("e_equipmentLabel", "");
                            return;
                          }
                          const found = equipments.find((eq) => eq.id === id);
                          updateField("e_equipmentId", id);
                          updateField("e_equipmentLabel", found?.name || "");
                        }}
                      >
                        <option value="">선택</option>
                        <option value={noneOption}>해당없음</option>
                        {equipments.map((e) => (
                          <option key={e.id} value={e.id}>{e.name}</option>
                        ))}
                      </select>
                      <button type="button" className="btn" onClick={() => setShowEquipForm((v) => !v)}>
                        {showEquipForm ? "닫기" : "추가"}
                      </button>
                    </div>
                  </div>

                  {showEquipForm ? (
                    <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
                      <div style={{ display: "grid", gap: 8 }}>
                        <div><div className="p" style={{ marginTop: 0 }}>설비명</div><input className="input" value={equipDraft.name} onChange={(e) => setEquipDraft({ ...equipDraft, name: e.target.value })} /></div>
                        <div><div className="p" style={{ marginTop: 0 }}>설치 위치/구역</div><input className="input" value={equipDraft.location} onChange={(e) => setEquipDraft({ ...equipDraft, location: e.target.value })} /></div>

                        <div>
                          <div className="p" style={{ marginTop: 0 }}>설비 구분</div>
                          <div className="row" style={{ marginTop: 8 }}>
                            {(["생산설비", "유통설비", "공용설비", "기타"] as const).map((t) => (
                              <button key={t} type="button" className={`selBtn ${equipDraft.equipType === t ? "active" : ""}`} onClick={() => setEquipDraft({ ...equipDraft, equipType: t })}>
                                {t}
                              </button>
                            ))}
                          </div>
                          <input className="input" value={equipDraft.equipTypeNote} onChange={(e) => setEquipDraft({ ...equipDraft, equipTypeNote: e.target.value })} placeholder="구분 설명(한 줄)" />
                        </div>

                        <div>
                          <div className="p" style={{ marginTop: 0 }}>중요도</div>
                          <div className="row" style={{ marginTop: 8 }}>
                            {(["상", "중", "하"] as const).map((v) => (
                              <button key={v} type="button" className={`selBtn ${equipDraft.importance === v ? "active" : ""}`} onClick={() => setEquipDraft({ ...equipDraft, importance: v })}>
                                {v}
                              </button>
                            ))}
                          </div>
                        </div>

                        <div><div className="p" style={{ marginTop: 0 }}>제조사/모델</div><input className="input" value={equipDraft.makerModel} onChange={(e) => setEquipDraft({ ...equipDraft, makerModel: e.target.value })} /></div>

                        <div>
                          <div className="p" style={{ marginTop: 0 }}>설치일</div>
                          <input className="input" inputMode="numeric" value={equipDraft.installedAt} onChange={(e) => setEquipDraft({ ...equipDraft, installedAt: e.target.value.replace(/[^0-9-]/g, "").slice(0, 10) })} placeholder="YYYY-MM-DD" />
                        </div>

                        <div>
                          <div className="p" style={{ marginTop: 0 }}>점검 주기</div>
                          <div className="row" style={{ marginTop: 8 }}>
                            {(["주간", "월간", "분기", "반기", "연간", "비정기"] as const).map((v) => (
                              <button key={v} type="button" className={`selBtn ${equipDraft.inspectCycle === v ? "active" : ""}`} onClick={() => setEquipDraft({ ...equipDraft, inspectCycle: v })}>
                                {v}
                              </button>
                            ))}
                          </div>
                          <input className="input" value={equipDraft.inspectNote} onChange={(e) => setEquipDraft({ ...equipDraft, inspectNote: e.target.value })} placeholder="주기 설명(한 줄)" />
                        </div>

                        {equipDraft.name.trim() && equipments.some((e) => (e.name || "").trim() === equipDraft.name.trim() && e.id !== equipEditId) ? (
                          <div style={{ display: "grid", gap: 6 }}>
                            <div className="p" style={{ marginTop: 0, opacity: 0.8 }}>동일한 설비명이 있습니다.</div>
                            <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 8 }}>
                              <select className="input" value={equipDupId} onChange={(e) => setEquipDupId(e.target.value)}>
                                {equipments.filter((e) => (e.name || "").trim() === equipDraft.name.trim()).map((e) => (
                                  <option key={e.id} value={e.id}>{e.name} · {e.location}</option>
                                ))}
                              </select>
                              <button type="button" className="btn" onClick={() => loadEquipToEdit(equipDupId)}>수정</button>
                            </div>
                          </div>
                        ) : null}

                        <div className="row">
                          <button type="button" className="btn primary" onClick={submitEquip}>{equipEditId ? "수정" : "저장"}</button>
                          <button type="button" className="btn" onClick={() => { resetEquipDraft(); setShowEquipForm(false); }}>취소</button>
                        </div>
                      </div>
                    </div>
                  ) : null}

                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
                    <div className="p">증상</div>
                    <textarea className="textarea" rows={2} value={issueDraft.e_symptom} onChange={(e) => updateField("e_symptom", e.target.value)} />
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
                    <div className="p">조치</div>
                    <textarea className="textarea" rows={2} value={issueDraft.e_action} onChange={(e) => updateField("e_action", e.target.value)} />
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
                    <div className="p">예방</div>
                    <textarea className="textarea" rows={2} value={issueDraft.e_prevent} onChange={(e) => updateField("e_prevent", e.target.value)} />
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
                    <div className="p">상태</div>
                    <select className="input" value={issueDraft.e_status} onChange={(e) => updateField("e_status", e.target.value as any)}>
                      <option value="진행중">진행중</option>
                      <option value="완료">완료</option>
                    </select>
                  </div>
                </>
              ) : null}

              {issueDraft.category === "safety" ? (
                <>
                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
                    <div className="p">직원</div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 8, alignItems: "center" }}>
                      <select
                        className="input"
                        value={issueDraft.s_employeeId || ""}
                        onChange={(e) => {
                          const id = e.target.value;
                          if (id === noneOption) {
                            updateField("s_employeeId", noneOption);
                            updateField("s_employeeLabel", "");
                            return;
                          }
                          const found = employees.find((emp) => emp.id === id);
                          updateField("s_employeeId", id);
                          updateField("s_employeeLabel", found?.name || "");
                        }}
                      >
                        <option value="">선택</option>
                        <option value={noneOption}>해당없음</option>
                        {employees.map((e) => (
                          <option key={e.id} value={e.id}>{e.name}</option>
                        ))}
                      </select>
                      <button type="button" className="btn" onClick={() => setShowEmpForm((v) => !v)}>
                        {showEmpForm ? "닫기" : "추가"}
                      </button>
                    </div>
                  </div>

                  {showEmpForm ? (
                    <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
                      <div style={{ display: "grid", gap: 8 }}>
                        <div><div className="p" style={{ marginTop: 0 }}>이름</div><input className="input" value={empDraft.name} onChange={(e) => setEmpDraft({ ...empDraft, name: e.target.value })} /></div>

                        <div>
                          <div className="p" style={{ marginTop: 0 }}>지부</div>
                          <div className="row" style={{ marginTop: 8 }}>
                            {(["대구", "성주"] as const).map((b) => (
                              <button key={b} type="button" className={`selBtn ${empDraft.branch === b ? "active" : ""}`} onClick={() => setEmpDraft({ ...empDraft, branch: b })}>
                                {b}
                              </button>
                            ))}
                          </div>
                        </div>

                        <div><div className="p" style={{ marginTop: 0 }}>연락처</div><input className="input" value={empDraft.phone} onChange={(e) => setEmpDraft({ ...empDraft, phone: e.target.value })} /></div>
                        <div><div className="p" style={{ marginTop: 0 }}>직무</div><input className="input" value={empDraft.job} onChange={(e) => setEmpDraft({ ...empDraft, job: e.target.value })} /></div>
                        <div><div className="p" style={{ marginTop: 0 }}>참고사항</div><textarea className="textarea" rows={2} value={empDraft.memo} onChange={(e) => setEmpDraft({ ...empDraft, memo: e.target.value })} /></div>

                        {empDraft.name.trim() && employees.some((e) => (e.name || "").trim() === empDraft.name.trim() && e.id !== empEditId) ? (
                          <div style={{ display: "grid", gap: 6 }}>
                            <div className="p" style={{ marginTop: 0, opacity: 0.8 }}>동일한 직원명이 있습니다.</div>
                            <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 8 }}>
                              <select className="input" value={empDupId} onChange={(e) => setEmpDupId(e.target.value)}>
                                {employees.filter((e) => (e.name || "").trim() === empDraft.name.trim()).map((e) => (
                                  <option key={e.id} value={e.id}>{e.name} · {e.branch}</option>
                                ))}
                              </select>
                              <button type="button" className="btn" onClick={() => loadEmpToEdit(empDupId)}>수정</button>
                            </div>
                          </div>
                        ) : null}

                        <div className="row">
                          <button type="button" className="btn primary" onClick={submitEmp}>{empEditId ? "수정" : "저장"}</button>
                          <button type="button" className="btn" onClick={() => { resetEmpDraft(); setShowEmpForm(false); }}>취소</button>
                        </div>
                      </div>
                    </div>
                  ) : null}

                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
                    <div className="p">위험도</div>
                    <select className="input" value={issueDraft.s_risk} onChange={(e) => updateField("s_risk", e.target.value as any)}>
                      <option value="낮음">낮음</option>
                      <option value="보통">보통</option>
                      <option value="높음">높음</option>
                    </select>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "center" }}>
                    <div className="p">장소</div>
                    <input className="input" value={issueDraft.s_location} onChange={(e) => updateField("s_location", e.target.value)} />
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
                    <div className="p">조치</div>
                    <textarea className="textarea" rows={2} value={issueDraft.s_action} onChange={(e) => updateField("s_action", e.target.value)} />
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: 8, alignItems: "start" }}>
                    <div className="p">예방</div>
                    <textarea className="textarea" rows={2} value={issueDraft.s_prevent} onChange={(e) => updateField("s_prevent", e.target.value)} />
                  </div>
                </>
              ) : null}

              <div className="row">
                <button type="button" className="btn primary" onClick={submitIssue}>저장</button>
                <button type="button" className="btn" onClick={() => { setOpen(false); setIssueDraft(defaultIssueDraft()); }}>취소</button>
              </div>
            </div>
          </div>
        ) : null}

        {items.length ? (
          <div style={{ marginTop: 8, display: "grid", gap: 8 }}>
            {items.map((it) => (
              <div key={it.id} className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 8 }}>
                  <div>
                    <div style={{ fontWeight: 800 }}>{it.title}{it.site ? ` (${it.site})` : ""}</div>
                    <div className="p" style={{ marginTop: 6, opacity: 0.8 }}>{it.category} · {it.createdAt}</div>
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button type="button" className="btn" onClick={() => alert(it.details || "")} title="상세">보기</button>
                    <button type="button" className="btn danger" onClick={() => doRemove(it.id)}>삭제</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : null}
      </div>
    );
  }

  const recent = useMemo(() => docs.slice(0, 30), [docs]);

  return (
    <div className="card">
      <h1 className="h1">생산일지</h1>

      <div style={{ marginTop: 14, display: "grid", gap: 10 }}>
        <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "center" }}>
          <div className="p" style={{ marginTop: 0 }}>기록날짜</div>
          <input className="input" type="date" value={draft.recordDate} onChange={(e) => persist({ ...draft, recordDate: e.target.value })} />
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "center" }}>
          <div className="p" style={{ marginTop: 0 }}>지부</div>
          <div className="row" style={{ marginTop: 0 }}>
            {(["대구", "성주"] as const).map((s) => (
              <button key={s} type="button" className={`selBtn ${draft.site === s ? "active" : ""}`} onClick={() => persist({ ...draft, site: s })}>
                {s}
              </button>
            ))}
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "center" }}>
          <div className="p" style={{ marginTop: 0 }}>작성자</div>
          <input className="input" value={draft.writerName} onChange={(e) => persist({ ...draft, writerName: e.target.value })} />
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "center" }}>
          <div className="p" style={{ marginTop: 0 }}>직책</div>
          <input className="input" value={draft.writerRole} onChange={(e) => persist({ ...draft, writerRole: e.target.value })} />
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "center" }}>
          <div className="p" style={{ marginTop: 0 }}>제목</div>
          <input className="input" value={draft.title} onFocus={onFocusTitle} onChange={(e) => onChangeTitle(e.target.value)} placeholder="클릭하면 자동완성" />
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "start" }}>
          <div className="p" style={{ marginTop: 0 }}>내용</div>
          <textarea ref={detailsRef} className="textarea" rows={3} value={draft.details} onChange={(e) => persist({ ...draft, details: e.target.value })} />
        </div>

        {/* 추천 태그 */}
        {visibleSug.length ? (
          <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "start" }}>
            <div className="p" style={{ marginTop: 0 }}>추천 태그</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}>
              {visibleSug.map((s) => {
                const isSystem = s.source === "system";
                return (
                  <div
                    key={`${s.source}:${s.tag}`}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      borderRadius: 999,
                      overflow: "hidden",
                      border: isSystem ? "1px solid rgba(70,130,255,0.65)" : "1px solid rgba(255,255,255,0.10)",
                      background: isSystem ? "rgba(70,130,255,0.20)" : "rgba(255,255,255,0.06)",
                    }}
                  >
                    <button
                      type="button"
                      className="btn"
                      style={{
                        borderRadius: 0,
                        background: "transparent",
                        padding: "8px 10px",
                        flex: 3,
                        textAlign: "left",
                      }}
                      onClick={() => applySuggested(s)}
                    >
                      #{s.tag}
                    </button>

                    <button
                      type="button"
                      className="btn"
                      style={{
                        borderRadius: 0,
                        background: "rgba(255,70,70,0.18)",
                        borderLeft: "1px solid rgba(255,70,70,0.25)",
                        padding: "8px 10px",
                        flex: 1,
                        minWidth: 46,
                      }}
                      title="추천에서 제외"
                      onClick={() => dismissSuggested(s.tag)}
                    >
                      🗑
                    </button>
                  </div>
                );
              })}

              {allSug.length > 5 ? (
                <button type="button" className="btn" onClick={() => setShowAll((v) => !v)}>
                  {showAll ? "접기" : `더보기(${allSug.length})`}
                </button>
              ) : null}
            </div>
          </div>
        ) : null}

        <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "start" }}>
          <div className="p" style={{ marginTop: 0 }}>태그</div>
          <div>
            <ConfirmedTagChips tagsText={draft.tagsText} onRemove={(t) => preserve(() => {
              const arr = (draft.tagsText || "").split(",").map((y) => y.trim()).filter(Boolean).filter((y) => y !== t);
              persist({ ...draft, tagsText: arr.join(", ") });
            })} compact={true} />

            <TagInputText value={draft.tagsText} onChange={(next) => persist({ ...draft, tagsText: next })} scope="production" showChips={false} />
          </div>
        </div>

        {/* 이슈 추가/연결 섹션 */}
        <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "start", marginTop: 6 }}>
          <div className="p" style={{ marginTop: 0 }}>이슈</div>
          <div>
            <IssuePanel />
          </div>
        </div>
      </div>

      <div className="divider" />

      <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
        <div className="h1" style={{ fontSize: 15 }}>생산 항목</div>

        <div className="row" style={{ marginTop: 10, gap: 8, flexWrap: "wrap" }}>
          <button type="button" className={`selBtn ${addMode === "line" ? "active" : ""}`} onClick={() => toggle("line")}>
            항목 추가
          </button>
        </div>

        {addMode === "line" ? (
          <div className="card" style={{ marginTop: 12, background: "rgba(255,255,255,0.02)" }}>
            <div style={{ marginTop: 10, display: "grid", gap: 10 }}>
              <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "center" }}>
                <div className="p" style={{ marginTop: 0 }}>근무</div>
                <div className="row" style={{ marginTop: 0 }}>
                  {(["주간", "오후", "야간"] as const).map((s: Shift) => (
                    <button key={s} type="button" className={`selBtn ${line.shift === s ? "active" : ""}`} onClick={() => setLine({ ...line, shift: s })}>
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "center" }}>
                <div className="p" style={{ marginTop: 0 }}>생산품</div>
                <div className="row" style={{ marginTop: 0 }}>
                  {(["분쇄품", "펠렛"] as const).map((p: Product) => (
                    <button key={p} type="button" className={`selBtn ${line.product === p ? "active" : ""}`} onClick={() => setLine({ ...line, product: p })}>
                      {p}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "center" }}>
                <div className="p" style={{ marginTop: 0 }}>품목</div>
                <div className="row" style={{ marginTop: 0 }}>
                  {(["PP", "PE"] as const).map((it: Item) => (
                    <button key={it} type="button" className={`selBtn ${line.item === it ? "active" : ""}`} onClick={() => setLine({ ...line, item: it })}>
                      {it}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "center" }}>
                <div className="p" style={{ marginTop: 0 }}>자루</div>
                <input className="input" inputMode="numeric" value={String(line.bags)} onChange={(e) => setLine({ ...line, bags: Number(e.target.value || 0) })} />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "center" }}>
                <div className="p" style={{ marginTop: 0 }}>Kg(선택)</div>
                <input className="input" inputMode="numeric" value={String(line.kg)} onChange={(e) => setLine({ ...line, kg: Number(e.target.value || 0) })} />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "110px 1fr", gap: 10, alignItems: "start" }}>
                <div className="p" style={{ marginTop: 0 }}>비고</div>
                <textarea className="textarea" rows={2} value={line.memo} onChange={(e) => setLine({ ...line, memo: e.target.value })} />
              </div>
            </div>

            <div className="row">
              <button type="button" className="btn primary" onClick={addLine}>추가</button>
            </div>
          </div>
        ) : null}

        {(draft.lines || []).length ? (
          <div style={{ marginTop: 12, display: "grid", gap: 10 }}>
            {(draft.lines || []).map((x) => (
              <div key={x.id} className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                  <div>
                    <div style={{ fontWeight: 900 }}>
                      {x.shift} · {x.product} · {x.item}
                    </div>
                    <div className="p" style={{ marginTop: 6 }}>
                      {x.bags}자루{x.kg ? ` · ${x.kg}kg` : ""}{x.memo ? ` · ${x.memo}` : ""}
                    </div>
                  </div>
                  <button type="button" className="btn danger" onClick={() => removeLine(x.id)}>삭제</button>
                </div>
              </div>
            ))}
          </div>
        ) : <p className="p" style={{ marginTop: 10 }}>아직 없음</p>}
      </div>

      <div className="row">
        <button type="button" className="btn primary" onClick={upsertSave}>저장</button>
        <button
          type="button"
          className="btn"
          onClick={() => {
            clear();
            reset();
            setRaw(defaultProductionDraft());
            setAddMode("none");
            setLine(newLine());
            setTitleAuto(false);
            titleTouchedRef.current = false;
          }}
        >
          초기화
        </button>
      </div>

      <div className="divider" />

      <div className="card" style={{ background: "rgba(255,255,255,0.02)" }}>
        <div className="h1" style={{ fontSize: 15 }}>최근 문서</div>

        {recent.length === 0 ? (
          <p className="p">아직 없음</p>
        ) : (
          recent.map((d) => (
            <div key={d.id} className="card" style={{ marginTop: 10, background: "rgba(255,255,255,0.02)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                <div>
                  <div style={{ fontWeight: 900 }}>
                    {d.recordDate} · {d.site} · {(d.writerName || "-")} {(d.writerRole || "")} · {d.title}
                  </div>
                  <div className="p" style={{ marginTop: 6, opacity: 0.8 }}>
                    항목 {d.lines?.length || 0}개 · updated {d.updatedAt}
                  </div>
                </div>

                <button type="button" className="btn danger" onClick={() => removeDoc(d.id)}>삭제</button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}